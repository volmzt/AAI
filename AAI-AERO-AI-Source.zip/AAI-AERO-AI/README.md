# AAI: AERO AI

Автономный ИИ-помощник для Android с локальной языковой моделью (offline first).
Нативное приложение: Kotlin, Jetpack Compose, Material 3. Языки интерфейса: RU / UK / EN.

## Статус: Этап 1 — основа

Реализовано в этой сборке:
- Gradle-проект (Kotlin DSL), один модуль `:app`, minSdk 26, targetSdk 35
- Темы: тёмная / светлая / системная, выбор акцентного цвета, отключение анимаций
- Локализация RU / UK / EN через Android resources, переключение языка в настройках
- Приветственный экран первого запуска, навигация, экран настроек (DataStore)
- Логотип AAI (Canvas) и адаптивная иконка
- GitHub Actions: unit-тесты, debug и release APK, проверка APK, artifacts

**Не реализовано (честно):** чаты, локальный ИИ (llama.cpp), память, обучение, интернет-поиск.
Кнопки и поле ввода на главном экране отключены, пока их этапы не сделаны.
Дорожная карта: этап 2 — чаты и Room; этап 3 — llama.cpp через JNI и Model Manager; далее по плану из мастер-промпта.

## Как получить APK
См. [BUILD.md](BUILD.md). Кратко: загрузить проект в GitHub → вкладка **Actions** → **Build APK** → artifact `AAI-AERO-AI-debug`.

## Локальная проверка
Нужны JDK 17, Android SDK (platform 35) и Gradle 8.10+ (или Android Studio):
```
gradle testDebugUnitTest assembleDebug
```

## Лицензия
Файл LICENSE не добавлен: выберите лицензию сами перед публикацией.
