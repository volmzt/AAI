package com.aero.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aero.ai.R
import com.aero.ai.data.Accent
import com.aero.ai.data.AppLanguage
import com.aero.ai.data.AppSettings
import com.aero.ai.data.LanguageManager
import com.aero.ai.data.SettingsRepository
import com.aero.ai.data.ThemeMode
import com.aero.ai.ui.ModelsViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    repo: SettingsRepository,
    modelsVm: ModelsViewModel,
    onBack: () -> Unit,
    onOpenModels: () -> Unit,
) {
    val settings by repo.settings.collectAsState(initial = AppSettings())
    val models by modelsVm.models.collectAsState()
    val activeId by modelsVm.activeModelId.collectAsState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val versionName = remember(context) {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "?"
    }
    val currentLanguage = LanguageManager.current()
    val activeName = models.firstOrNull { it.id == activeId }?.name

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            SettingsGroup(stringResource(R.string.group_ai)) {
                SettingRow(
                    glyph = "🧠",
                    title = stringResource(R.string.models_title),
                    subtitle = activeName ?: stringResource(R.string.models_subtitle_none),
                    onClick = onOpenModels,
                    trailing = { Chevron() },
                )
            }

            SettingsGroup(stringResource(R.string.group_appearance)) {
                DropdownRow(
                    glyph = "🌗",
                    title = stringResource(R.string.theme),
                    value = stringResource(themeLabel(settings.themeMode)),
                    options = ThemeMode.entries.map { mode ->
                        stringResource(themeLabel(mode)) to { scope.launch { repo.setThemeMode(mode) }; Unit }
                    },
                )
                RowDivider()
                DropdownRow(
                    glyph = "🎨",
                    title = stringResource(R.string.accent),
                    value = stringResource(accentLabel(settings.accent)),
                    dot = Color(settings.accent.argb),
                    options = Accent.entries.map { a ->
                        stringResource(accentLabel(a)) to { scope.launch { repo.setAccent(a) }; Unit }
                    },
                )
                RowDivider()
                SettingRow(
                    glyph = "✨",
                    title = stringResource(R.string.animations),
                    trailing = {
                        Switch(
                            checked = settings.animations,
                            onCheckedChange = { scope.launch { repo.setAnimations(it) } },
                        )
                    },
                )
                RowDivider()
                DropdownRow(
                    glyph = "🌐",
                    title = stringResource(R.string.language),
                    value = languageLabel(currentLanguage),
                    options = AppLanguage.entries.map { lang ->
                        languageLabel(lang) to { LanguageManager.apply(lang) }
                    },
                )
            }

            SettingsGroup(stringResource(R.string.group_planned)) {
                PlannedRow("🗂️", stringResource(R.string.memory_title), 4)
                RowDivider()
                PlannedRow("🌍", stringResource(R.string.internet_title), 5)
                RowDivider()
                PlannedRow("📈", stringResource(R.string.learning_title), 6)
                RowDivider()
                PlannedRow("🔒", stringResource(R.string.security_title), null)
            }

            SettingsGroup(stringResource(R.string.group_about)) {
                SettingRow(
                    glyph = "ℹ️",
                    title = stringResource(R.string.app_name),
                    subtitle = stringResource(R.string.version_fmt, versionName),
                )
            }
        }
    }
}

private fun themeLabel(mode: ThemeMode): Int = when (mode) {
    ThemeMode.SYSTEM -> R.string.theme_system
    ThemeMode.DARK -> R.string.theme_dark
    ThemeMode.LIGHT -> R.string.theme_light
}

private fun accentLabel(accent: Accent): Int = when (accent) {
    Accent.ORANGE -> R.string.accent_orange
    Accent.BLUE -> R.string.accent_blue
    Accent.GREEN -> R.string.accent_green
    Accent.PURPLE -> R.string.accent_purple
}

@Composable
fun SettingsGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Text(
            title,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(start = 12.dp, bottom = 8.dp),
        )
        Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
            Column(content = content)
        }
    }
}

@Composable
fun RowDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(start = 68.dp),
        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
    )
}

@Composable
fun Chevron() {
    Text("›", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
fun SettingRow(
    glyph: String,
    title: String,
    subtitle: String? = null,
    onClick: (() -> Unit)? = null,
    trailing: @Composable () -> Unit = {},
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center,
        ) { Text(glyph) }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        trailing()
    }
}

@Composable
private fun DropdownRow(
    glyph: String,
    title: String,
    value: String,
    options: List<Pair<String, () -> Unit>>,
    dot: Color? = null,
) {
    var open by remember { mutableStateOf(false) }
    Box {
        SettingRow(glyph = glyph, title = title, onClick = { open = true }) {
            if (dot != null) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(dot))
                Spacer(Modifier.width(8.dp))
            }
            Text("$value ▾", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (label, action) ->
                DropdownMenuItem(text = { Text(label) }, onClick = { open = false; action() })
            }
        }
    }
}

@Composable
private fun PlannedRow(glyph: String, title: String, stage: Int?) {
    Box(Modifier.alpha(0.6f)) {
        SettingRow(
            glyph = glyph,
            title = title,
            subtitle = if (stage != null) stringResource(R.string.planned_stage_fmt, stage) else stringResource(R.string.planned_label),
        )
    }
}
