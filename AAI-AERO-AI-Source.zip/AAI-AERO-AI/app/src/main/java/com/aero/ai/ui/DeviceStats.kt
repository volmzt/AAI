package com.aero.ai.ui

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.view.Display
import java.util.Locale

/** Real readings from the device; any value that cannot be read is null. */
data class DeviceStats(
    val deviceName: String,
    val androidVersion: String,
    val apiLevel: Int,
    val soc: String,
    val cores: Int,
    val ramTotal: Long,
    val ramFree: Long,
    val storageTotal: Long,
    val storageFree: Long,
    val batteryPercent: Int?,
    val batteryTempC: Float?,
    val screen: String,
    val refreshHz: Int?,
) {
    val ramUsedPercent: Int get() = if (ramTotal > 0) (100 - ramFree * 100 / ramTotal).toInt() else 0
    val storageUsedPercent: Int get() = if (storageTotal > 0) (100 - storageFree * 100 / storageTotal).toInt() else 0

    companion object {
        fun read(context: Context): DeviceStats {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
            val fs = StatFs(Environment.getDataDirectory().path)
            val battery = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val temp = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
            val dm = context.resources.displayMetrics
            val display = (context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager)
                .getDisplay(Display.DEFAULT_DISPLAY)
            val soc = if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotBlank()) Build.SOC_MODEL else Build.HARDWARE
            return DeviceStats(
                deviceName = Build.MANUFACTURER.replaceFirstChar { it.titlecase(Locale.ROOT) } + " " + Build.MODEL,
                androidVersion = Build.VERSION.RELEASE,
                apiLevel = Build.VERSION.SDK_INT,
                soc = soc,
                cores = Runtime.getRuntime().availableProcessors(),
                ramTotal = mi.totalMem,
                ramFree = mi.availMem,
                storageTotal = fs.totalBytes,
                storageFree = fs.availableBytes,
                batteryPercent = if (level >= 0 && scale > 0) level * 100 / scale else null,
                batteryTempC = if (temp != Int.MIN_VALUE) temp / 10f else null,
                screen = "${dm.widthPixels} × ${dm.heightPixels}",
                refreshHz = display?.refreshRate?.toInt(),
            )
        }
    }
}
