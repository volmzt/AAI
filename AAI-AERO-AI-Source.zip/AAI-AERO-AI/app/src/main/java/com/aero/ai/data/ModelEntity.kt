package com.aero.ai.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "model_registry")
data class ModelEntity(
    @PrimaryKey val id: String,
    val name: String,
    val fileName: String,
    val sizeBytes: Long,
    val sha256: String,
    val format: String,
    val importedAt: Long,
)

@Dao
interface ModelDao {
    @Insert
    suspend fun insert(model: ModelEntity)

    @Query("SELECT * FROM model_registry ORDER BY importedAt DESC")
    fun observeAll(): Flow<List<ModelEntity>>

    @Query("SELECT * FROM model_registry WHERE id = :id")
    suspend fun get(id: String): ModelEntity?

    @Query("DELETE FROM model_registry WHERE id = :id")
    suspend fun delete(id: String)
}
