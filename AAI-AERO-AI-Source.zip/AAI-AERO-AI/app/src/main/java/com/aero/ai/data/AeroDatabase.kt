package com.aero.ai.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [ChatEntity::class, MessageEntity::class, ModelEntity::class],
    version = 2,
    exportSchema = false,
)
abstract class AeroDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun modelDao(): ModelDao

    companion object {
        @Volatile private var instance: AeroDatabase? = null

        /** Adds the model registry. Existing chats and messages are untouched. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `model_registry` (" +
                        "`id` TEXT NOT NULL, `name` TEXT NOT NULL, `fileName` TEXT NOT NULL, " +
                        "`sizeBytes` INTEGER NOT NULL, `sha256` TEXT NOT NULL, `format` TEXT NOT NULL, " +
                        "`importedAt` INTEGER NOT NULL, PRIMARY KEY(`id`))"
                )
            }
        }

        fun get(context: Context): AeroDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                AeroDatabase::class.java,
                "aero.db",
            ).addMigrations(MIGRATION_1_2).build().also { instance = it }
        }
    }
}
