package com.aero.ai.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.aero.ai.R
import com.aero.ai.ai.EngineState
import com.aero.ai.ui.AeroLogo
import com.aero.ai.ui.ModelsViewModel

/** First-run step: get a language model (download from the catalog or import a file). */
@Composable
fun SetupScreen(vm: ModelsViewModel, onDone: () -> Unit) {
    val engine by vm.engineState.collectAsState()
    val message by vm.message.collectAsState()
    val progress by vm.importProgress.collectAsState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importModel(uri)
    }
    // As soon as a model is loaded the setup is finished and the chat opens.
    LaunchedEffect(engine) { if (engine is EngineState.Ready) onDone() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Spacer(Modifier.height(12.dp))
        AeroLogo(size = 72.dp)
        Text(stringResource(R.string.setup_title), style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
        Text(
            stringResource(R.string.setup_desc),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        message?.let { res ->
            Text(
                stringResource(res),
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.clickable { vm.dismissMessage() },
            )
        }
        when (val e = engine) {
            is EngineState.Loading -> Text(stringResource(R.string.engine_loading))
            is EngineState.Failed -> Text(stringResource(e.messageRes), color = MaterialTheme.colorScheme.error)
            else -> {}
        }
        CatalogSection(vm)
        OutlinedButton(
            onClick = { picker.launch(arrayOf("*/*")) },
            enabled = progress == null,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(
                if (progress == null) stringResource(R.string.setup_import)
                else stringResource(R.string.importing_unknown)
            )
        }
        TextButton(onClick = onDone) { Text(stringResource(R.string.setup_later)) }
    }
}
