package com.aero.ai.ui.screens

import android.text.format.Formatter
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import com.aero.ai.R
import com.aero.ai.data.CatalogModel
import com.aero.ai.data.ModelCatalog
import com.aero.ai.ui.DlState
import com.aero.ai.ui.ModelsViewModel
import com.aero.ai.ui.components.AeroCard
import com.aero.ai.ui.components.SectionLabel
import androidx.compose.foundation.layout.Column
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.padding

/** The built-in model catalog with one-tap download. */
@Composable
fun CatalogSection(vm: ModelsViewModel) {
    val models by vm.models.collectAsState()
    val dl by vm.download.collectAsState()
    val context = LocalContext.current
    var confirm by remember { mutableStateOf<CatalogModel?>(null) }
    val busy = dl !is DlState.None

    SectionLabel(stringResource(R.string.catalog_title))
    ModelCatalog.all.forEach { item ->
        val installed = models.any { it.name == item.displayName }
        AeroCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.title, style = MaterialTheme.typography.titleLarge)
                    Text(item.baseModel, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (item.recommended) {
                    Text(
                        stringResource(R.string.catalog_recommended),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
            Text(stringResource(item.hintRes), style = MaterialTheme.typography.bodyMedium)
            Text(
                stringResource(R.string.catalog_size_fmt, Formatter.formatFileSize(context, item.approxBytes)) +
                    " · " + stringResource(R.string.catalog_license_fmt, item.license),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            val s = dl
            when {
                s is DlState.Starting && s.catalogId == item.id -> {
                    LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 6.dp))
                    Text(stringResource(R.string.catalog_starting), style = MaterialTheme.typography.bodySmall)
                }
                s is DlState.Running && s.catalogId == item.id -> {
                    val frac = if (s.total > 0) (s.done.toFloat() / s.total).coerceIn(0f, 1f) else 0f
                    LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (s.waiting) stringResource(R.string.catalog_waiting)
                            else stringResource(
                                R.string.catalog_progress_fmt,
                                Formatter.formatFileSize(context, s.done),
                                Formatter.formatFileSize(context, s.total),
                            ),
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = { vm.cancelDownload() }) { Text(stringResource(R.string.catalog_cancel)) }
                    }
                }
                s is DlState.Finalizing && s.catalogId == item.id -> {
                    LinearProgressIndicator(progress = { s.percent / 100f }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
                    Text(stringResource(R.string.catalog_verifying_fmt, s.percent), style = MaterialTheme.typography.bodySmall)
                }
                installed -> Text(
                    stringResource(R.string.catalog_installed),
                    color = MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.labelLarge,
                )
                else -> Button(
                    onClick = { if (vm.isMetered()) confirm = item else vm.startDownload(item) },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                ) { Text(stringResource(R.string.catalog_download)) }
            }
        }
    }
    Text(
        stringResource(R.string.catalog_note),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 8.dp),
    )

    confirm?.let { item ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            text = { Text(stringResource(R.string.confirm_metered_fmt, Formatter.formatFileSize(context, item.approxBytes))) },
            confirmButton = {
                TextButton(onClick = { vm.startDownload(item); confirm = null }) { Text(stringResource(R.string.catalog_download)) }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}
