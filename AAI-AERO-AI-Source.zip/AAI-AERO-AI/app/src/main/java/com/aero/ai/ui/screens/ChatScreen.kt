package com.aero.ai.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aero.ai.R
import com.aero.ai.data.ChatEntity
import com.aero.ai.data.MessageEntity
import com.aero.ai.ui.AeroLogo
import com.aero.ai.ui.ChatsViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    vm: ChatsViewModel,
    onOpenSettings: () -> Unit,
    onOpenArchive: () -> Unit,
    onOpenTrash: () -> Unit,
) {
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val currentId by vm.currentChatId.collectAsState()
    val chat by vm.currentChat.collectAsState()
    val messages by vm.messages.collectAsState()
    var moreOpen by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<ChatEntity?>(null) }
    val youLabel = stringResource(R.string.you)
    val exportTitle = stringResource(R.string.export_chat)

    BackHandler(enabled = drawer.isOpen) { scope.launch { drawer.close() } }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ChatDrawer(
                vm = vm,
                currentId = currentId,
                onPick = { id -> vm.openChat(id); scope.launch { drawer.close() } },
                onNew = { vm.newChat(); scope.launch { drawer.close() } },
                onRename = { renaming = it },
                onOpenArchive = { scope.launch { drawer.close() }; onOpenArchive() },
                onOpenTrash = { scope.launch { drawer.close() }; onOpenTrash() },
            )
        },
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawer.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = stringResource(R.string.open_history))
                        }
                    },
                    title = { AeroLogo(size = 28.dp) },
                    actions = {
                        Box {
                            IconButton(onClick = { moreOpen = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = stringResource(R.string.menu_more))
                            }
                            DropdownMenu(expanded = moreOpen, onDismissRequest = { moreOpen = false }) {
                                val c = chat
                                if (c != null) {
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.rename)) },
                                        onClick = { moreOpen = false; renaming = c },
                                    )
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.export_chat)) },
                                        onClick = {
                                            moreOpen = false
                                            scope.launch {
                                                val text = vm.exportText(c.id, youLabel)
                                                val send = Intent(Intent.ACTION_SEND).apply {
                                                    type = "text/plain"
                                                    putExtra(Intent.EXTRA_SUBJECT, c.title)
                                                    putExtra(Intent.EXTRA_TEXT, text)
                                                }
                                                context.startActivity(Intent.createChooser(send, exportTitle))
                                            }
                                        },
                                    )
                                }
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.settings)) },
                                    onClick = { moreOpen = false; onOpenSettings() },
                                )
                            }
                        }
                    },
                )
            },
        ) { padding ->
            ChatBody(
                messages = messages,
                onSend = vm::send,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .consumeWindowInsets(padding)
                    .imePadding(),
            )
        }
    }

    renaming?.let { c ->
        RenameDialog(
            initial = c.title,
            onDismiss = { renaming = null },
            onSave = { vm.rename(c.id, it); renaming = null },
        )
    }
}

@Composable
private fun ChatBody(messages: List<MessageEntity>, onSend: (String) -> Unit, modifier: Modifier) {
    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }
    Column(modifier) {
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            if (messages.isEmpty()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    AeroLogo(size = 64.dp)
                    Text(
                        stringResource(R.string.start_conversation),
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(top = 16.dp),
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(messages, key = { it.id }) { MessageBubble(it) }
                }
            }
        }
        Text(
            stringResource(R.string.no_model_note),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        )
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text(stringResource(R.string.input_hint)) },
                maxLines = 6,
                modifier = Modifier.weight(1f),
            )
            IconButton(
                onClick = { onSend(input); input = "" },
                enabled = input.isNotBlank(),
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = stringResource(R.string.send))
            }
        }
    }
}

@Composable
private fun MessageBubble(message: MessageEntity) {
    val mine = message.role == MessageEntity.ROLE_USER
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start,
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (mine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
            contentColor = if (mine) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.widthIn(max = 320.dp),
        ) {
            SelectionContainer {
                Text(message.text, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChatDrawer(
    vm: ChatsViewModel,
    currentId: String?,
    onPick: (String) -> Unit,
    onNew: () -> Unit,
    onRename: (ChatEntity) -> Unit,
    onOpenArchive: () -> Unit,
    onOpenTrash: () -> Unit,
) {
    val results by vm.searchResults.collectAsState()
    val query by vm.query.collectAsState()
    val archivedCount = vm.archived.collectAsState().value.size
    val trashCount = vm.trash.collectAsState().value.size
    var menuFor by remember { mutableStateOf<String?>(null) }

    ModalDrawerSheet {
        Column(Modifier.fillMaxHeight()) {
            Button(
                onClick = onNew,
                modifier = Modifier.fillMaxWidth().padding(16.dp),
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Text(stringResource(R.string.new_chat), modifier = Modifier.padding(start = 8.dp))
            }
            OutlinedTextField(
                value = query,
                onValueChange = vm::setQuery,
                singleLine = true,
                placeholder = { Text(stringResource(R.string.search_chats)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            )
            if (results.isEmpty()) {
                Text(
                    stringResource(R.string.no_chats),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp),
                )
            }
            LazyColumn(Modifier.weight(1f)) {
                items(results, key = { it.id }) { chat ->
                    Box {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .combinedClickable(
                                    onClick = { onPick(chat.id) },
                                    onLongClick = { menuFor = chat.id },
                                )
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            if (chat.pinned) {
                                Icon(
                                    Icons.Default.Star,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp).padding(end = 0.dp),
                                )
                                Box(Modifier.size(8.dp))
                            }
                            Text(
                                chat.title,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                fontWeight = if (chat.id == currentId) FontWeight.Bold else FontWeight.Normal,
                            )
                        }
                        DropdownMenu(expanded = menuFor == chat.id, onDismissRequest = { menuFor = null }) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.rename)) },
                                onClick = { menuFor = null; onRename(chat) },
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(if (chat.pinned) R.string.unpin else R.string.pin)) },
                                onClick = { menuFor = null; vm.togglePin(chat) },
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.archive)) },
                                onClick = { menuFor = null; vm.archive(chat) },
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.delete)) },
                                onClick = { menuFor = null; vm.moveToTrash(chat) },
                            )
                        }
                    }
                }
            }
            HorizontalDivider()
            TextButton(onClick = onOpenArchive, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.list_with_count, stringResource(R.string.archive), archivedCount))
            }
            TextButton(onClick = onOpenTrash, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.list_with_count, stringResource(R.string.trash), trashCount))
            }
        }
    }
}

@Composable
private fun RenameDialog(initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.rename_title)) },
        text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
        confirmButton = {
            TextButton(onClick = { onSave(text) }, enabled = text.isNotBlank()) {
                Text(stringResource(R.string.save))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}
