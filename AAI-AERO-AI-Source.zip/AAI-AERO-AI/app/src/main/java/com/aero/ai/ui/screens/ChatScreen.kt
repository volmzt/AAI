package com.aero.ai.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aero.ai.R
import com.aero.ai.ai.EngineState
import com.aero.ai.data.ChatEntity
import com.aero.ai.data.MessageEntity
import com.aero.ai.ui.AeroLogo
import com.aero.ai.ui.ChatsViewModel
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(
    vm: ChatsViewModel,
    onOpenSettings: () -> Unit,
    onOpenModels: () -> Unit,
    onOpenArchive: () -> Unit,
    onOpenTrash: () -> Unit,
) {
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val currentId by vm.currentChatId.collectAsState()
    val chat by vm.currentChat.collectAsState()
    val messages by vm.messages.collectAsState()
    val generating by vm.generating.collectAsState()
    val streaming by vm.streamingText.collectAsState()
    val errorRes by vm.errorRes.collectAsState()
    val activeModelId by vm.activeModelId.collectAsState()
    val engine by vm.engineState.collectAsState()
    var moreOpen by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<ChatEntity?>(null) }
    val youLabel = stringResource(R.string.you)
    val exportTitle = stringResource(R.string.export_chat)

    BackHandler(enabled = drawer.isOpen) { scope.launch { drawer.close() } }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ChatDrawer(
                vm = vm,
                currentId = currentId,
                onPick = { id -> vm.openChat(id); scope.launch { drawer.close() } },
                onNew = { vm.newChat(); scope.launch { drawer.close() } },
                onRename = { renaming = it },
                onOpenArchive = { scope.launch { drawer.close() }; onOpenArchive() },
                onOpenTrash = { scope.launch { drawer.close() }; onOpenTrash() },
            )
        },
    ) {
        Box(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            ChatBody(
                messages = messages,
                generating = generating,
                streaming = streaming,
                engineLoading = engine is EngineState.Loading,
                errorRes = errorRes,
                noModel = activeModelId == null && !generating,
                onDismissError = vm::dismissError,
                onOpenModels = onOpenModels,
                onSend = vm::send,
                onStop = vm::stopGeneration,
                onRegenerate = vm::regenerate,
                modifier = Modifier.fillMaxSize(),
            )
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FloatingCircle(onClick = { scope.launch { drawer.open() } }) {
                    Icon(Icons.Default.Menu, contentDescription = stringResource(R.string.open_history))
                }
                Spacer(Modifier.weight(1f))
                AeroLogo(size = 26.dp)
                Spacer(Modifier.weight(1f))
                Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                    Row {
                        IconButton(onClick = { vm.newChat() }) {
                            Icon(Icons.Default.Add, contentDescription = stringResource(R.string.new_chat))
                        }
                        Box {
                            IconButton(onClick = { moreOpen = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = stringResource(R.string.menu_more))
                            }
                            DropdownMenu(expanded = moreOpen, onDismissRequest = { moreOpen = false }) {
                                val c = chat
                                if (c != null) {
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.rename)) },
                                        onClick = { moreOpen = false; renaming = c },
                                    )
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.export_chat)) },
                                        onClick = {
                                            moreOpen = false
                                            scope.launch {
                                                val text = vm.exportText(c.id, youLabel)
                                                val send = Intent(Intent.ACTION_SEND).apply {
                                                    type = "text/plain"
                                                    putExtra(Intent.EXTRA_SUBJECT, c.title)
                                                    putExtra(Intent.EXTRA_TEXT, text)
                                                }
                                                context.startActivity(Intent.createChooser(send, exportTitle))
                                            }
                                        },
                                    )
                                }
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.settings)) },
                                    onClick = { moreOpen = false; onOpenSettings() },
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    renaming?.let { c ->
        RenameDialog(
            initial = c.title,
            onDismiss = { renaming = null },
            onSave = { vm.rename(c.id, it); renaming = null },
        )
    }
}

@Composable
private fun FloatingCircle(onClick: () -> Unit, content: @Composable () -> Unit) {
    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.size(44.dp)) {
        IconButton(onClick = onClick, modifier = Modifier.fillMaxSize()) { content() }
    }
}

@Composable
private fun ChatBody(
    messages: List<MessageEntity>,
    generating: Boolean,
    streaming: String,
    engineLoading: Boolean,
    errorRes: Int?,
    noModel: Boolean,
    onDismissError: () -> Unit,
    onOpenModels: () -> Unit,
    onSend: (String) -> Unit,
    onStop: () -> Unit,
    onRegenerate: () -> Unit,
    modifier: Modifier,
) {
    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()
    val itemCount = messages.size + if (generating) 1 else 0
    LaunchedEffect(itemCount) { listState.scrollToItem(0) }
    val pending = if (engineLoading) stringResource(R.string.engine_loading) else "…"

    Column(modifier) {
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            if (messages.isEmpty() && !generating) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    AeroLogo(size = 64.dp)
                    Text(
                        stringResource(R.string.start_conversation),
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(top = 16.dp),
                    )
                }
            } else {
                // Reverse layout keeps the newest message pinned to the bottom while text streams in.
                LazyColumn(
                    state = listState,
                    reverseLayout = true,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 68.dp, bottom = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    if (generating) {
                        item(key = "stream") { AssistantMessage(if (streaming.isEmpty()) pending else streaming) }
                    } else if (messages.isNotEmpty()) {
                        item(key = "regen") {
                            TextButton(onClick = onRegenerate) { Text(stringResource(R.string.regenerate)) }
                        }
                    }
                    items(messages.asReversed(), key = { it.id }) { m ->
                        if (m.role == MessageEntity.ROLE_USER) UserMessage(m.text) else AssistantMessage(m.text)
                    }
                }
            }
        }
        if (errorRes != null) {
            Banner(
                text = stringResource(errorRes),
                textColor = MaterialTheme.colorScheme.error,
                actionLabel = stringResource(R.string.dismiss),
                onAction = onDismissError,
            )
        } else if (noModel) {
            Banner(
                text = stringResource(R.string.banner_no_model),
                textColor = MaterialTheme.colorScheme.onSurfaceVariant,
                actionLabel = stringResource(R.string.models_button),
                onAction = onOpenModels,
            )
        }
        InputPill(
            value = input,
            onValueChange = { input = it },
            generating = generating,
            onSend = { onSend(input); input = "" },
            onStop = onStop,
        )
    }
}

@Composable
private fun Banner(text: String, textColor: Color, actionLabel: String, onAction: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
    ) {
        Row(Modifier.padding(start = 16.dp, end = 4.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(text, color = textColor, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            TextButton(onClick = onAction) { Text(actionLabel) }
        }
    }
}

@Composable
private fun InputPill(
    value: String,
    onValueChange: (String) -> Unit,
    generating: Boolean,
    onSend: () -> Unit,
    onStop: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
        Row(Modifier.padding(start = 6.dp, end = 6.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.Bottom) {
            TextField(
                value = value,
                onValueChange = onValueChange,
                placeholder = { Text(stringResource(R.string.input_hint)) },
                maxLines = 6,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    disabledContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent,
                ),
                modifier = Modifier.weight(1f),
            )
            if (generating) {
                FilledIconButton(onClick = onStop, modifier = Modifier.padding(bottom = 4.dp)) {
                    Box(Modifier.size(14.dp).background(LocalContentColor.current, RoundedCornerShape(3.dp)))
                }
            } else {
                FilledIconButton(onClick = onSend, enabled = value.isNotBlank(), modifier = Modifier.padding(bottom = 4.dp)) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = stringResource(R.string.send))
                }
            }
        }
    }
}

@Composable
private fun UserMessage(text: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        Surface(
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomStart = 20.dp, bottomEnd = 6.dp),
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.20f),
            modifier = Modifier.widthIn(max = 320.dp),
        ) {
            SelectionContainer {
                Text(text, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
            }
        }
    }
}

@Composable
private fun AssistantMessage(text: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        AeroLogo(size = 20.dp, modifier = Modifier.padding(top = 3.dp))
        Spacer(Modifier.width(10.dp))
        SelectionContainer(Modifier.weight(1f)) {
            Text(text, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChatDrawer(
    vm: ChatsViewModel,
    currentId: String?,
    onPick: (String) -> Unit,
    onNew: () -> Unit,
    onRename: (ChatEntity) -> Unit,
    onOpenArchive: () -> Unit,
    onOpenTrash: () -> Unit,
) {
    val results by vm.searchResults.collectAsState()
    val query by vm.query.collectAsState()
    val archivedCount = vm.archived.collectAsState().value.size
    val trashCount = vm.trash.collectAsState().value.size
    var menuFor by remember { mutableStateOf<String?>(null) }

    ModalDrawerSheet {
        Column(Modifier.fillMaxHeight()) {
            Button(onClick = onNew, modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Text(stringResource(R.string.new_chat), modifier = Modifier.padding(start = 8.dp))
            }
            OutlinedTextField(
                value = query,
                onValueChange = vm::setQuery,
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
                placeholder = { Text(stringResource(R.string.search_chats)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            )
            if (results.isEmpty()) {
                Text(
                    stringResource(R.string.no_chats),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp),
                )
            }
            LazyColumn(Modifier.weight(1f)) {
                items(results, key = { it.id }) { chat ->
                    Box {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .combinedClickable(
                                    onClick = { onPick(chat.id) },
                                    onLongClick = { menuFor = chat.id },
                                )
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            if (chat.pinned) {
                                Icon(
                                    Icons.Default.Star,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp),
                                )
                                Spacer(Modifier.width(8.dp))
                            }
                            Text(
                                chat.title,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                fontWeight = if (chat.id == currentId) FontWeight.Bold else FontWeight.Normal,
                            )
                        }
                        DropdownMenu(expanded = menuFor == chat.id, onDismissRequest = { menuFor = null }) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.rename)) },
                                onClick = { menuFor = null; onRename(chat) },
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(if (chat.pinned) R.string.unpin else R.string.pin)) },
                                onClick = { menuFor = null; vm.togglePin(chat) },
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.archive)) },
                                onClick = { menuFor = null; vm.archive(chat) },
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.delete)) },
                                onClick = { menuFor = null; vm.moveToTrash(chat) },
                            )
                        }
                    }
                }
            }
            HorizontalDivider()
            TextButton(onClick = onOpenArchive, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.list_with_count, stringResource(R.string.archive), archivedCount))
            }
            TextButton(onClick = onOpenTrash, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.list_with_count, stringResource(R.string.trash), trashCount))
            }
        }
    }
}

@Composable
private fun RenameDialog(initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.rename_title)) },
        text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
        confirmButton = {
            TextButton(onClick = { onSave(text) }, enabled = text.isNotBlank()) {
                Text(stringResource(R.string.save))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}
