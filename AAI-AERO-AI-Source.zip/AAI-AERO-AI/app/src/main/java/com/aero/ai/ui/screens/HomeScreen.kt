package com.aero.ai.ui.screens

import android.text.format.Formatter
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aero.ai.R
import com.aero.ai.ai.EngineState
import com.aero.ai.ai.LlmEngine
import com.aero.ai.data.AppSettings
import com.aero.ai.data.SettingsRepository
import com.aero.ai.ui.AeroLogo
import com.aero.ai.ui.DeviceStats
import com.aero.ai.ui.ModelsViewModel
import com.aero.ai.ui.components.AeroCard
import com.aero.ai.ui.components.SectionLabel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private val Good = Color(0xFF45B97C)

@Composable
fun HomeScreen(
    modelsVm: ModelsViewModel,
    repo: SettingsRepository,
    onOpenChat: () -> Unit,
    onOpenModels: () -> Unit,
) {
    val context = LocalContext.current
    var stats by remember { mutableStateOf(DeviceStats.read(context)) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(2000)
            stats = withContext(Dispatchers.IO) { DeviceStats.read(context) }
        }
    }
    val engine by modelsVm.engineState.collectAsState()
    val models by modelsVm.models.collectAsState()
    val activeId by modelsVm.activeModelId.collectAsState()
    val speed by LlmEngine.lastSpeed.collectAsState()
    val settings by repo.settings.collectAsState(initial = AppSettings())
    val activeName = models.firstOrNull { it.id == activeId }?.name

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            AeroLogo(size = 44.dp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text("AERO", style = MaterialTheme.typography.displayMedium)
                Text(
                    stringResource(R.string.home_subtitle),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        // Model hero card
        AeroCard {
            Text(stringResource(R.string.home_model_label), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                activeName ?: stringResource(R.string.models_subtitle_none),
                style = MaterialTheme.typography.headlineMedium,
            )
            val (stateText, stateColor) = when (val e = engine) {
                is EngineState.Ready -> stringResource(R.string.home_state_loaded) to Good
                is EngineState.Loading -> stringResource(R.string.engine_loading) to MaterialTheme.colorScheme.primary
                is EngineState.Failed -> stringResource(e.messageRes) to MaterialTheme.colorScheme.error
                is EngineState.Idle ->
                    if (activeName != null) stringResource(R.string.home_state_idle) to MaterialTheme.colorScheme.onSurfaceVariant
                    else stringResource(R.string.home_state_none) to MaterialTheme.colorScheme.onSurfaceVariant
            }
            Text(stateText, color = stateColor, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onOpenChat, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.home_open_chat)) }
                OutlinedButton(onClick = onOpenModels, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.nav_models)) }
            }
        }

        // Live stats
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            StatCard(
                modifier = Modifier.weight(1f),
                label = stringResource(R.string.stat_ram),
                value = "${stats.ramUsedPercent}%",
                note = stringResource(R.string.stat_free_fmt, Formatter.formatFileSize(context, stats.ramFree)),
            )
            StatCard(
                modifier = Modifier.weight(1f),
                label = stringResource(R.string.stat_speed),
                value = speed?.let { String.format("%.1f", it) } ?: "—",
                note = if (speed != null) stringResource(R.string.unit_toks) else stringResource(R.string.stat_no_data),
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            StatCard(
                modifier = Modifier.weight(1f),
                label = stringResource(R.string.stat_storage),
                value = "${stats.storageUsedPercent}%",
                note = stringResource(R.string.stat_free_fmt, Formatter.formatFileSize(context, stats.storageFree)),
            )
            StatCard(
                modifier = Modifier.weight(1f),
                label = stringResource(R.string.stat_battery),
                value = stats.batteryPercent?.let { "$it%" } ?: "—",
                note = stats.batteryTempC?.let { String.format("%.1f °C", it) } ?: stringResource(R.string.stat_unavailable),
            )
        }

        // Generation settings summary
        AeroCard {
            Text(stringResource(R.string.home_generation), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                stringResource(R.string.home_generation_fmt, settings.contextSize, settings.threads, settings.temperature.toString()),
                style = MaterialTheme.typography.titleMedium,
            )
        }

        // Device
        AeroCard {
            Text(stringResource(R.string.home_device), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(stats.deviceName, style = MaterialTheme.typography.headlineMedium)
            Text(
                stringResource(R.string.home_android_fmt, stats.androidVersion, stats.apiLevel, stats.soc, stats.cores),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "RAM " + Formatter.formatFileSize(context, stats.ramTotal) + " · " + stats.screen +
                    (stats.refreshHz?.let { " · $it Hz" } ?: ""),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(110.dp))
    }
}

@Composable
private fun StatCard(modifier: Modifier, label: String, value: String, note: String) {
    AeroCard(modifier = modifier) {
        Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.headlineLarge)
        Text(note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
