package com.aero.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aero.ai.R
import com.aero.ai.ui.ChatsViewModel

enum class ManageKind { ARCHIVE, TRASH }

private class PendingAction(val message: String, val run: () -> Unit)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManageChatsScreen(kind: ManageKind, vm: ChatsViewModel, onBack: () -> Unit) {
    val archive = kind == ManageKind.ARCHIVE
    val chats by (if (archive) vm.archived else vm.trash).collectAsState()
    var pending by remember { mutableStateOf<PendingAction?>(null) }
    val msgForever = stringResource(R.string.confirm_delete_forever)
    val msgEmpty = stringResource(R.string.confirm_empty_trash)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(if (archive) R.string.archive else R.string.trash)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
                actions = {
                    if (!archive && chats.isNotEmpty()) {
                        TextButton(onClick = { pending = PendingAction(msgEmpty) { vm.emptyTrash() } }) {
                            Text(stringResource(R.string.empty_trash))
                        }
                    }
                },
            )
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (!archive) {
                Text(
                    stringResource(R.string.trash_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp),
                )
            }
            if (chats.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        stringResource(if (archive) R.string.archive_empty else R.string.trash_empty),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(chats, key = { it.id }) { chat ->
                        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                            Text(chat.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                if (archive) {
                                    TextButton(onClick = { vm.unarchive(chat) }) { Text(stringResource(R.string.unarchive)) }
                                    TextButton(onClick = { vm.moveToTrash(chat) }) { Text(stringResource(R.string.delete)) }
                                } else {
                                    TextButton(onClick = { vm.restore(chat) }) { Text(stringResource(R.string.restore)) }
                                    TextButton(onClick = { pending = PendingAction(msgForever) { vm.deleteForever(chat) } }) {
                                        Text(stringResource(R.string.delete_forever))
                                    }
                                }
                            }
                            HorizontalDivider()
                        }
                    }
                }
            }
        }
    }

    pending?.let { p ->
        AlertDialog(
            onDismissRequest = { pending = null },
            text = { Text(p.message) },
            confirmButton = {
                TextButton(onClick = { p.run(); pending = null }) { Text(stringResource(R.string.delete_forever)) }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}
