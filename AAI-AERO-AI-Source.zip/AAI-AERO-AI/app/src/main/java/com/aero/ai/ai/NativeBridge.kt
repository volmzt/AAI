package com.aero.ai.ai

import android.util.Log

/** Receives raw UTF-8 bytes of each generated token piece. Return false to stop generation. */
fun interface TokenCallback {
    fun onToken(bytes: ByteArray): Boolean
}

/** JNI entry points implemented in src/main/cpp/aero_native.cpp (llama.cpp). */
object NativeBridge {
    val isAvailable: Boolean = try {
        System.loadLibrary("aero_native")
        true
    } catch (t: Throwable) {
        Log.e("NativeBridge", "Native library failed to load", t)
        false
    }

    external fun nativeLoad(path: String): Long
    external fun nativeFree(handle: Long)
    /** "description|sizeBytes|trainedContext|parameters" */
    external fun nativeInfo(handle: Long): String
    external fun nativeLastError(): String
    external fun nativeCancel()

    /** Returns null on success (or cancel), otherwise a short error code such as "context_full". */
    external fun nativeGenerate(
        handle: Long,
        roles: Array<String>,
        contents: Array<ByteArray>,
        nCtx: Int,
        nThreads: Int,
        maxTokens: Int,
        temperature: Float,
        topP: Float,
        callback: TokenCallback,
    ): String?
}
