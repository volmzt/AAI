package com.aero.ai.data

import android.content.Context
import java.io.File
import java.io.InputStream
import java.security.MessageDigest

object ModelStore {
    fun dir(context: Context): File = File(context.filesDir, "models").apply { mkdirs() }

    fun hex(bytes: ByteArray): String = bytes.joinToString("") { "%02x".format(it) }

    fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { copyInto(it, md) }
        return hex(md.digest())
    }

    private fun copyInto(input: InputStream, md: MessageDigest) {
        val buf = ByteArray(1 shl 20)
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            md.update(buf, 0, n)
        }
    }

    /** GGUF files start with the ASCII magic "GGUF". */
    fun isGgufMagic(first4: ByteArray): Boolean =
        first4.size == 4 && String(first4, Charsets.US_ASCII) == "GGUF"
}
