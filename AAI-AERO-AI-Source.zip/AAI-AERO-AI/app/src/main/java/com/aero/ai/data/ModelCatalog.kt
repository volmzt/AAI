package com.aero.ai.data

import androidx.annotation.StringRes
import com.aero.ai.R

/** A model AERO can download. Files come from the official Qwen repositories on Hugging Face. */
data class CatalogModel(
    val id: String,
    val title: String,
    val baseModel: String,
    val repo: String,
    val file: String,
    val approxBytes: Long,
    val license: String,
    @StringRes val hintRes: Int,
    val recommended: Boolean = false,
) {
    val url: String get() = "https://huggingface.co/$repo/resolve/main/$file"
    /** Name stored in the model registry. */
    val displayName: String get() = "$title · $baseModel"
}

object ModelCatalog {
    val all: List<CatalogModel> = listOf(
        CatalogModel(
            id = "aero-lite",
            title = "AERO Lite",
            baseModel = "Qwen2.5 0.5B Instruct",
            repo = "Qwen/Qwen2.5-0.5B-Instruct-GGUF",
            file = "qwen2.5-0.5b-instruct-q4_k_m.gguf",
            approxBytes = 400L * 1024 * 1024,
            license = "Apache-2.0",
            hintRes = R.string.catalog_hint_lite,
        ),
        CatalogModel(
            id = "aero-standard",
            title = "AERO Standard",
            baseModel = "Qwen2.5 1.5B Instruct",
            repo = "Qwen/Qwen2.5-1.5B-Instruct-GGUF",
            file = "qwen2.5-1.5b-instruct-q4_k_m.gguf",
            approxBytes = 1100L * 1024 * 1024,
            license = "Apache-2.0",
            hintRes = R.string.catalog_hint_standard,
            recommended = true,
        ),
        CatalogModel(
            id = "aero-pro",
            title = "AERO Pro",
            baseModel = "Qwen2.5 3B Instruct",
            repo = "Qwen/Qwen2.5-3B-Instruct-GGUF",
            file = "qwen2.5-3b-instruct-q4_k_m.gguf",
            approxBytes = 2000L * 1024 * 1024,
            license = "Qwen Research (non-commercial)",
            hintRes = R.string.catalog_hint_pro,
        ),
    )

    fun byId(id: String): CatalogModel? = all.firstOrNull { it.id == id }
}

/** A download handed to Android's DownloadManager; kept so it can be resumed after the app was closed. */
data class PendingDownload(val catalogId: String, val downloadId: Long, val expectedSha: String) {
    fun encode(): String = "$catalogId|$downloadId|$expectedSha"

    companion object {
        fun decode(raw: String?): PendingDownload? {
            if (raw.isNullOrBlank()) return null
            val parts = raw.split("|")
            if (parts.size != 3) return null
            val id = parts[1].toLongOrNull() ?: return null
            return PendingDownload(parts[0], id, parts[2])
        }
    }
}
