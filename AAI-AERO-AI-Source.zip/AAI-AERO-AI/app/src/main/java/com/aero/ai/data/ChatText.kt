package com.aero.ai.data

/** Pure text helpers (no Android dependencies, covered by unit tests). */
object ChatText {
    const val MAX_TITLE = 40

    /** Chat title from the first non-empty line of the first message. */
    fun titleFrom(text: String): String {
        val line = text.lineSequence().map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: ""
        return if (line.length > MAX_TITLE) line.take(MAX_TITLE).trimEnd() + "…" else line
    }

    /** Escapes LIKE wildcards; the SQL query uses ESCAPE '\'. */
    fun escapeLike(query: String): String =
        query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
}
