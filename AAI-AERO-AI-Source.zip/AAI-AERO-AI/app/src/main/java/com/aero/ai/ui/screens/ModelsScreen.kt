package com.aero.ai.ui.screens

import android.text.format.Formatter
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aero.ai.R
import com.aero.ai.ai.EngineState
import com.aero.ai.data.AppSettings
import com.aero.ai.data.GenerationOptions
import com.aero.ai.data.ModelEntity
import com.aero.ai.data.SettingsRepository
import com.aero.ai.ui.ModelsViewModel
import com.aero.ai.ui.components.AeroCard
import com.aero.ai.ui.components.ScreenTitle
import com.aero.ai.ui.components.SectionLabel
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ModelsScreen(vm: ModelsViewModel, repo: SettingsRepository) {
    val models by vm.models.collectAsState()
    val activeId by vm.activeModelId.collectAsState()
    val engine by vm.engineState.collectAsState()
    val progress by vm.importProgress.collectAsState()
    val message by vm.message.collectAsState()
    val settings by repo.settings.collectAsState(initial = AppSettings())
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var verifyFor by remember { mutableStateOf<ModelEntity?>(null) }
    var deleteFor by remember { mutableStateOf<ModelEntity?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importModel(uri)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        ScreenTitle(stringResource(R.string.models_title))

        message?.let { res ->
            Text(
                stringResource(res),
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.clickable { vm.dismissMessage() },
            )
        }
        when (val e = engine) {
            is EngineState.Loading -> Text(stringResource(R.string.engine_loading))
            is EngineState.Failed -> Text(stringResource(e.messageRes), color = MaterialTheme.colorScheme.error)
            else -> {}
        }

        SectionLabel(stringResource(R.string.models_installed))
        if (models.isEmpty()) {
            Text(stringResource(R.string.models_empty), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 8.dp))
        }
        models.forEach { m ->
            val loaded = engine.let { it is EngineState.Ready && it.modelId == m.id }
            AeroCard {
                Text(m.name, style = MaterialTheme.typography.titleLarge)
                Text(
                    Formatter.formatFileSize(context, m.sizeBytes) + " · " + m.format + " · SHA-256 " + m.sha256.take(12) + "…",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                val status = buildList {
                    if (m.id == activeId) add(stringResource(R.string.model_active))
                    add(stringResource(if (loaded) R.string.model_loaded else R.string.model_not_loaded))
                }.joinToString(" · ")
                Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                if (loaded) {
                    val info = (engine as EngineState.Ready).info.split("|")
                    if (info.size >= 3) {
                        Text(
                            stringResource(R.string.model_info_fmt, info[0], info[2]),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (!loaded || m.id != activeId) {
                        TextButton(onClick = { vm.useAsMain(m) }) { Text(stringResource(R.string.use_model)) }
                    }
                    if (loaded) TextButton(onClick = { vm.unload() }) { Text(stringResource(R.string.unload_model)) }
                    TextButton(onClick = { vm.clearHash(); verifyFor = m }) { Text(stringResource(R.string.verify_hash)) }
                    TextButton(onClick = { deleteFor = m }) { Text(stringResource(R.string.delete)) }
                }
            }
        }

        CatalogSection(vm)

        SectionLabel(stringResource(R.string.import_model))
        val p = progress
        if (p != null) {
            AeroCard {
                Text(
                    if (p >= 0) stringResource(R.string.importing_fmt, p) else stringResource(R.string.importing_unknown),
                    style = MaterialTheme.typography.bodyMedium,
                )
                if (p >= 0) LinearProgressIndicator(progress = { p / 100f }, modifier = Modifier.fillMaxWidth())
                else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
        } else {
            OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.import_model))
            }
        }
        Text(
            stringResource(R.string.models_help),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 8.dp),
        )

        SectionLabel(stringResource(R.string.gen_settings))
        AeroCard {
            ChipRow(stringResource(R.string.gen_context), GenerationOptions.contexts, settings.contextSize, { it.toString() }) {
                scope.launch { repo.setContextSize(it) }
            }
            ChipRow(stringResource(R.string.gen_threads), GenerationOptions.threads, settings.threads, { it.toString() }) {
                scope.launch { repo.setThreads(it) }
            }
            ChipRow(stringResource(R.string.gen_temperature), GenerationOptions.temperatures, settings.temperature, { it.toString() }) {
                scope.launch { repo.setTemperature(it) }
            }
            ChipRow(stringResource(R.string.gen_max_tokens), GenerationOptions.maxTokens, settings.maxTokens, { it.toString() }) {
                scope.launch { repo.setMaxTokens(it) }
            }
            Text(
                stringResource(R.string.gen_note),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(110.dp))
    }

    verifyFor?.let { m -> VerifyDialog(m, vm) { verifyFor = null } }

    deleteFor?.let { m ->
        AlertDialog(
            onDismissRequest = { deleteFor = null },
            text = { Text(stringResource(R.string.confirm_delete_model)) },
            confirmButton = {
                TextButton(onClick = { vm.delete(m); deleteFor = null }) { Text(stringResource(R.string.delete)) }
            },
            dismissButton = { TextButton(onClick = { deleteFor = null }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun <T> ChipRow(title: String, options: List<T>, selected: T, label: (T) -> String, onPick: (T) -> Unit) {
    Text(title, style = MaterialTheme.typography.bodyMedium)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o ->
            FilterChip(selected = o == selected, onClick = { onPick(o) }, label = { Text(label(o)) })
        }
    }
}

@Composable
private fun VerifyDialog(model: ModelEntity, vm: ModelsViewModel, onDismiss: () -> Unit) {
    var expected by remember { mutableStateOf("") }
    val busy by vm.hashBusy.collectAsState()
    val result by vm.hashResult.collectAsState()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.verify_hash)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = expected,
                    onValueChange = { expected = it },
                    label = { Text(stringResource(R.string.expected_hash)) },
                    singleLine = true,
                )
                if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                result?.let { r ->
                    Text(stringResource(R.string.hash_computed_fmt, r.computed.ifEmpty { "—" }), style = MaterialTheme.typography.bodySmall)
                    Text(
                        stringResource(if (r.matchesStored) R.string.hash_intact else R.string.hash_changed),
                        color = if (r.matchesStored) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                    )
                    r.matchesExpected?.let { ok ->
                        Text(
                            stringResource(if (ok) R.string.hash_match else R.string.hash_mismatch),
                            color = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { vm.verify(model, expected) }, enabled = !busy) { Text(stringResource(R.string.verify_run)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) } },
    )
}
