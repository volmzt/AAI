package com.aero.ai.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import com.aero.ai.ai.AeroPrompts
import com.aero.ai.ai.ChatTurn
import com.aero.ai.ai.EngineState
import com.aero.ai.ai.GenResult
import com.aero.ai.ai.LlmEngine
import com.aero.ai.data.AeroDatabase
import com.aero.ai.data.ChatEntity
import com.aero.ai.data.ChatText
import com.aero.ai.data.MessageEntity
import com.aero.ai.data.SettingsRepository
import java.text.DateFormat
import java.util.Date
import java.util.UUID
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class ChatsViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AeroDatabase.get(app)
    private val dao = db.chatDao()
    private val modelDao = db.modelDao()
    private val prefs = SettingsRepository(app)
    private var genJob: Job? = null

    private fun <T> Flow<T>.asState(initial: T): StateFlow<T> =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), initial)

    val query = MutableStateFlow("")
    /** null = draft: the chat row is created when the first message is sent. */
    val currentChatId = MutableStateFlow<String?>(null)

    val generating = MutableStateFlow(false)
    val streamingText = MutableStateFlow("")
    val errorRes = MutableStateFlow<Int?>(null)
    val engineState: StateFlow<EngineState> = LlmEngine.state
    val activeModelId: StateFlow<String?> = prefs.activeModelId.asState(null)

    val archived = dao.observeArchived().asState(emptyList())
    val trash = dao.observeTrash().asState(emptyList())

    val searchResults: StateFlow<List<ChatEntity>> = query.flatMapLatest { q ->
        if (q.isBlank()) dao.observeActive() else dao.search(ChatText.escapeLike(q.trim()))
    }.asState(emptyList())

    val currentChat: StateFlow<ChatEntity?> = currentChatId.flatMapLatest { id ->
        if (id == null) flowOf<ChatEntity?>(null) else dao.observeChat(id)
    }.asState(null)

    val messages: StateFlow<List<MessageEntity>> = currentChatId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList<MessageEntity>()) else dao.observeMessages(id)
    }.asState(emptyList())

    init {
        viewModelScope.launch {
            dao.purgeTrashOlderThan(System.currentTimeMillis() - TRASH_RETENTION_MS)
            val last = prefs.lastChatId.first()
            if (last != null && currentChatId.value == null) {
                val chat = dao.getChat(last)
                if (chat != null && chat.deletedAt == null) currentChatId.value = last
            }
        }
    }

    fun setQuery(value: String) { query.value = value }

    fun newChat() {
        currentChatId.value = null
        viewModelScope.launch { prefs.setLastChatId(null) }
    }

    fun openChat(id: String) {
        currentChatId.value = id
        viewModelScope.launch { prefs.setLastChatId(id) }
    }

    fun send(rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty() || generating.value) return
        genJob = viewModelScope.launch {
            val now = System.currentTimeMillis()
            var id = currentChatId.value
            val isNew = id == null
            if (id == null) id = UUID.randomUUID().toString()
            val chatId: String = id
            db.withTransaction {
                if (isNew) dao.insertChat(ChatEntity(chatId, ChatText.titleFrom(text), now, now))
                dao.insertMessage(MessageEntity(chatId = chatId, role = MessageEntity.ROLE_USER, text = text, createdAt = now))
                dao.touch(chatId, now)
            }
            if (isNew) {
                currentChatId.value = chatId
                prefs.setLastChatId(chatId)
            }
            generateReply(chatId)
        }
    }

    fun stopGeneration() {
        LlmEngine.cancel()
    }

    fun dismissError() { errorRes.value = null }

    /** Re-runs the model on the current history; removes the last assistant answer first. */
    fun regenerate() {
        val id = currentChatId.value ?: return
        if (generating.value) return
        genJob = viewModelScope.launch {
            val last = dao.getMessages(id).lastOrNull() ?: return@launch
            if (last.role == MessageEntity.ROLE_ASSISTANT) dao.deleteMessage(last.id)
            generateReply(id)
        }
    }

    private suspend fun ensureModelReady(): Boolean {
        if (LlmEngine.state.value is EngineState.Ready) return true
        val id = prefs.activeModelId.first() ?: return false
        val model = modelDao.get(id) ?: return false
        return LlmEngine.load(getApplication(), model)
    }

    private suspend fun generateReply(chatId: String) {
        errorRes.value = null
        streamingText.value = ""
        generating.value = true
        val sb = StringBuilder()
        try {
            if (!ensureModelReady()) {
                (LlmEngine.state.value as? EngineState.Failed)?.let { errorRes.value = it.messageRes }
                return
            }
            val s = prefs.settings.first()
            val history = dao.getMessages(chatId).map { ChatTurn(it.role, it.text) }
            val turns = listOf(ChatTurn("system", AeroPrompts.SYSTEM)) + history
            val result = LlmEngine.generate(turns, s.contextSize, s.threads, s.maxTokens, s.temperature) { piece ->
                sb.append(piece)
                streamingText.value = sb.toString()
            }
            if (result is GenResult.Failed) errorRes.value = result.messageRes
            val reply = sb.toString().trim()
            if (reply.isNotEmpty()) {
                val now = System.currentTimeMillis()
                runCatching {
                    db.withTransaction {
                        dao.insertMessage(
                            MessageEntity(chatId = chatId, role = MessageEntity.ROLE_ASSISTANT, text = reply, createdAt = now)
                        )
                        dao.touch(chatId, now)
                    }
                }
            }
        } finally {
            generating.value = false
            streamingText.value = ""
        }
    }

    fun rename(id: String, title: String) {
        val t = title.trim()
        if (t.isEmpty()) return
        viewModelScope.launch { dao.rename(id, t, System.currentTimeMillis()) }
    }

    fun togglePin(chat: ChatEntity) {
        viewModelScope.launch { dao.setPinned(chat.id, !chat.pinned) }
    }

    fun archive(chat: ChatEntity) {
        leaveIfCurrent(chat.id)
        viewModelScope.launch { dao.setArchived(chat.id, true) }
    }

    fun unarchive(chat: ChatEntity) {
        viewModelScope.launch { dao.setArchived(chat.id, false) }
    }

    fun moveToTrash(chat: ChatEntity) {
        leaveIfCurrent(chat.id)
        viewModelScope.launch { dao.setDeletedAt(chat.id, System.currentTimeMillis()) }
    }

    fun restore(chat: ChatEntity) {
        viewModelScope.launch { dao.setDeletedAt(chat.id, null) }
    }

    fun deleteForever(chat: ChatEntity) {
        leaveIfCurrent(chat.id)
        viewModelScope.launch { dao.deleteChat(chat.id) }
    }

    fun emptyTrash() {
        viewModelScope.launch { dao.emptyTrash() }
    }

    suspend fun exportText(chatId: String, youLabel: String): String {
        val chat = dao.getChat(chatId) ?: return ""
        val fmt = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
        val sb = StringBuilder()
        sb.append(chat.title).append('\n').append(fmt.format(Date(chat.createdAt))).append("\n\n")
        for (m in dao.getMessages(chatId)) {
            val who = if (m.role == MessageEntity.ROLE_USER) youLabel else "AERO"
            sb.append('[').append(fmt.format(Date(m.createdAt))).append("] ")
                .append(who).append(":\n").append(m.text).append("\n\n")
        }
        return sb.toString().trimEnd()
    }

    private fun leaveIfCurrent(id: String) {
        if (currentChatId.value == id) newChat()
    }

    companion object {
        const val TRASH_RETENTION_MS = 30L * 24 * 60 * 60 * 1000
    }
}
