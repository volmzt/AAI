package com.aero.ai.ui

import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.aero.ai.data.AppSettings
import com.aero.ai.data.SettingsRepository
import com.aero.ai.ui.screens.ChatScreen
import com.aero.ai.ui.screens.ManageChatsScreen
import com.aero.ai.ui.screens.ManageKind
import com.aero.ai.ui.screens.SettingsScreen
import com.aero.ai.ui.screens.WelcomeScreen
import com.aero.ai.ui.theme.AeroTheme
import kotlinx.coroutines.launch

object Routes {
    const val WELCOME = "welcome"
    const val CHAT = "chat"
    const val SETTINGS = "settings"
    const val ARCHIVE = "archive"
    const val TRASH = "trash"
}

@Composable
fun AeroRoot(repo: SettingsRepository) {
    val loaded: AppSettings? by repo.settings.collectAsState(initial = null)
    val s = loaded
    if (s == null) {
        Box(Modifier.fillMaxSize().background(Color(0xFF101010)))
        return
    }
    AeroTheme(s.themeMode, s.accent) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            AeroNav(repo, s)
        }
    }
}

@Composable
private fun AeroNav(repo: SettingsRepository, settings: AppSettings) {
    val nav = rememberNavController()
    val vm: ChatsViewModel = viewModel()
    val scope = rememberCoroutineScope()
    // Start destination is fixed once, so later setting changes never rebuild the graph.
    val start = remember { if (settings.onboardingDone) Routes.CHAT else Routes.WELCOME }
    val animations = rememberUpdatedState(settings.animations)

    NavHost(
        navController = nav,
        startDestination = start,
        enterTransition = { if (animations.value) fadeIn(tween(200)) else EnterTransition.None },
        exitTransition = { if (animations.value) fadeOut(tween(200)) else ExitTransition.None },
        popEnterTransition = { if (animations.value) fadeIn(tween(200)) else EnterTransition.None },
        popExitTransition = { if (animations.value) fadeOut(tween(200)) else ExitTransition.None },
    ) {
        composable(Routes.WELCOME) {
            WelcomeScreen(onContinue = {
                scope.launch { repo.setOnboardingDone() }
                nav.navigate(Routes.CHAT) { popUpTo(Routes.WELCOME) { inclusive = true } }
            })
        }
        composable(Routes.CHAT) {
            ChatScreen(
                vm = vm,
                onOpenSettings = { nav.navigate(Routes.SETTINGS) },
                onOpenArchive = { nav.navigate(Routes.ARCHIVE) },
                onOpenTrash = { nav.navigate(Routes.TRASH) },
            )
        }
        composable(Routes.ARCHIVE) {
            ManageChatsScreen(ManageKind.ARCHIVE, vm, onBack = { nav.popBackStack() })
        }
        composable(Routes.TRASH) {
            ManageChatsScreen(ManageKind.TRASH, vm, onBack = { nav.popBackStack() })
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(repo = repo, onBack = { nav.popBackStack() })
        }
    }
}
