package com.aero.ai.ui

import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.aero.ai.data.AppSettings
import com.aero.ai.data.SettingsRepository
import com.aero.ai.ui.components.BottomPill
import com.aero.ai.ui.screens.ChatScreen
import com.aero.ai.ui.screens.HomeScreen
import com.aero.ai.ui.screens.ManageChatsScreen
import com.aero.ai.ui.screens.ManageKind
import com.aero.ai.ui.screens.ModelsScreen
import com.aero.ai.ui.screens.SettingsScreen
import com.aero.ai.ui.screens.SetupScreen
import com.aero.ai.ui.screens.WelcomeScreen
import com.aero.ai.ui.theme.AeroTheme
import kotlinx.coroutines.launch

object Routes {
    const val WELCOME = "welcome"
    const val SETUP = "setup"
    const val HOME = "home"
    const val CHAT = "chat"
    const val SETTINGS = "settings"
    const val MODELS = "models"
    const val ARCHIVE = "archive"
    const val TRASH = "trash"
}

@Composable
fun AeroRoot(repo: SettingsRepository) {
    val loaded: AppSettings? by repo.settings.collectAsState(initial = null)
    val s = loaded
    if (s == null) {
        Box(Modifier.fillMaxSize().background(Color(0xFF101010)))
        return
    }
    AeroTheme(s.themeMode, s.accent) {
        val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            // Soft accent glow at the top of every screen.
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(460.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(MaterialTheme.colorScheme.primary.copy(alpha = if (dark) 0.30f else 0.16f), Color.Transparent)
                        )
                    )
            )
            AeroNav(repo, s)
        }
    }
}

@Composable
private fun AeroNav(repo: SettingsRepository, settings: AppSettings) {
    val nav = rememberNavController()
    val scope = rememberCoroutineScope()
    val vm: ChatsViewModel = viewModel()
    val modelsVm: ModelsViewModel = viewModel()
    // Start destination is fixed once, so later setting changes never rebuild the graph.
    val start = remember { if (settings.onboardingDone) Routes.CHAT else Routes.WELCOME }
    val animations = rememberUpdatedState(settings.animations)
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val showPill = route == Routes.HOME || route == Routes.MODELS || route == Routes.SETTINGS

    fun go(target: String) {
        nav.navigate(target) {
            popUpTo(Routes.HOME) { inclusive = false }
            launchSingleTop = true
        }
    }

    Box(Modifier.fillMaxSize()) {
        NavHost(
            navController = nav,
            startDestination = start,
            enterTransition = { if (animations.value) fadeIn(tween(200)) else EnterTransition.None },
            exitTransition = { if (animations.value) fadeOut(tween(200)) else ExitTransition.None },
            popEnterTransition = { if (animations.value) fadeIn(tween(200)) else EnterTransition.None },
            popExitTransition = { if (animations.value) fadeOut(tween(200)) else ExitTransition.None },
        ) {
            composable(Routes.WELCOME) {
                WelcomeScreen(onContinue = {
                    scope.launch { repo.setOnboardingDone() }
                    nav.navigate(Routes.SETUP) { popUpTo(Routes.WELCOME) { inclusive = true } }
                })
            }
            composable(Routes.SETUP) {
                SetupScreen(vm = modelsVm, onDone = {
                    nav.navigate(Routes.CHAT) { popUpTo(Routes.SETUP) { inclusive = true } }
                })
            }
            composable(Routes.HOME) {
                HomeScreen(
                    modelsVm = modelsVm,
                    repo = repo,
                    onOpenChat = { go(Routes.CHAT) },
                    onOpenModels = { go(Routes.MODELS) },
                )
            }
            composable(Routes.CHAT) {
                ChatScreen(
                    vm = vm,
                    onOpenHome = { go(Routes.HOME) },
                    onOpenSettings = { go(Routes.SETTINGS) },
                    onOpenModels = { go(Routes.MODELS) },
                    onOpenArchive = { nav.navigate(Routes.ARCHIVE) },
                    onOpenTrash = { nav.navigate(Routes.TRASH) },
                )
            }
            composable(Routes.ARCHIVE) {
                ManageChatsScreen(ManageKind.ARCHIVE, vm, onBack = { nav.popBackStack() })
            }
            composable(Routes.TRASH) {
                ManageChatsScreen(ManageKind.TRASH, vm, onBack = { nav.popBackStack() })
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(repo = repo, modelsVm = modelsVm, onOpenModels = { go(Routes.MODELS) })
            }
            composable(Routes.MODELS) {
                ModelsScreen(vm = modelsVm, repo = repo)
            }
        }
        if (showPill) {
            BottomPill(
                selectedRoute = route,
                onNavigate = { go(it) },
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }
    }
}
