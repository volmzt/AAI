package com.aero.ai.ui

import android.app.Application
import android.net.Uri
import android.os.StatFs
import android.provider.OpenableColumns
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aero.ai.R
import com.aero.ai.ai.EngineState
import com.aero.ai.ai.LlmEngine
import com.aero.ai.data.AeroDatabase
import com.aero.ai.data.ModelEntity
import com.aero.ai.data.ModelStore
import com.aero.ai.data.SettingsRepository
import java.io.DataInputStream
import java.io.File
import java.security.MessageDigest
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HashResult(val computed: String, val matchesStored: Boolean, val matchesExpected: Boolean?)

class ModelsViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AeroDatabase.get(app).modelDao()
    private val prefs = SettingsRepository(app)

    val models: StateFlow<List<ModelEntity>> =
        dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val activeModelId: StateFlow<String?> =
        prefs.activeModelId.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val engineState: StateFlow<EngineState> = LlmEngine.state

    /** null = no import running; -1 = size unknown. */
    val importProgress = MutableStateFlow<Int?>(null)
    val message = MutableStateFlow<Int?>(null)
    val hashResult = MutableStateFlow<HashResult?>(null)
    val hashBusy = MutableStateFlow(false)

    fun dismissMessage() { message.value = null }
    fun clearHash() { hashResult.value = null }

    fun importModel(uri: Uri) {
        if (importProgress.value != null) return
        viewModelScope.launch(Dispatchers.IO) {
            importProgress.value = -1
            message.value = null
            val ctx = getApplication<Application>()
            val id = UUID.randomUUID().toString()
            val dir = ModelStore.dir(ctx)
            val part = File(dir, "$id.part")
            try {
                var displayName = "model.gguf"
                var size = -1L
                ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val si = c.getColumnIndex(OpenableColumns.SIZE)
                        if (ni >= 0) c.getString(ni)?.let { displayName = it }
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                    }
                }
                val isGguf = runCatching {
                    ctx.contentResolver.openInputStream(uri)!!.use { ins ->
                        val magic = ByteArray(4)
                        DataInputStream(ins).readFully(magic)
                        ModelStore.isGgufMagic(magic)
                    }
                }.getOrDefault(false)
                if (!isGguf) {
                    message.value = R.string.err_not_gguf
                    return@launch
                }
                if (size > 0 && StatFs(dir.path).availableBytes < size + (64L shl 20)) {
                    message.value = R.string.err_no_space
                    return@launch
                }
                val md = MessageDigest.getInstance("SHA-256")
                var copied = 0L
                var lastPercent = -2
                ctx.contentResolver.openInputStream(uri)!!.use { ins ->
                    part.outputStream().use { out ->
                        val buf = ByteArray(1 shl 20)
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            md.update(buf, 0, n)
                            copied += n
                            val pct = if (size > 0) (copied * 100 / size).toInt().coerceIn(0, 100) else -1
                            if (pct != lastPercent) {
                                lastPercent = pct
                                importProgress.value = pct
                            }
                        }
                    }
                }
                val finalFile = File(dir, "$id.gguf")
                if (!part.renameTo(finalFile)) error("rename failed")
                dao.insert(
                    ModelEntity(
                        id = id,
                        name = displayName.removeSuffix(".gguf").removeSuffix(".GGUF"),
                        fileName = finalFile.name,
                        sizeBytes = copied,
                        sha256 = ModelStore.hex(md.digest()),
                        format = "GGUF",
                        importedAt = System.currentTimeMillis(),
                    )
                )
            } catch (e: Exception) {
                Log.e("ModelsViewModel", "import failed", e)
                part.delete()
                message.value = R.string.err_import_failed
            } finally {
                importProgress.value = null
            }
        }
    }

    fun useAsMain(model: ModelEntity) {
        viewModelScope.launch {
            prefs.setActiveModelId(model.id)
            LlmEngine.load(getApplication(), model)
        }
    }

    fun unload() {
        viewModelScope.launch { LlmEngine.unload() }
    }

    fun delete(model: ModelEntity) {
        viewModelScope.launch {
            val st = LlmEngine.state.value
            if (st is EngineState.Ready && st.modelId == model.id) LlmEngine.unload()
            if (activeModelId.value == model.id) prefs.setActiveModelId(null)
            withIo { File(ModelStore.dir(getApplication()), model.fileName).delete() }
            dao.delete(model.id)
        }
    }

    fun verify(model: ModelEntity, expected: String) {
        if (hashBusy.value) return
        viewModelScope.launch {
            hashBusy.value = true
            hashResult.value = null
            try {
                val file = File(ModelStore.dir(getApplication()), model.fileName)
                val computed = withIo { if (file.exists()) ModelStore.sha256(file) else "" }
                val exp = expected.trim().lowercase()
                hashResult.value = HashResult(
                    computed = computed,
                    matchesStored = computed.isNotEmpty() && computed == model.sha256,
                    matchesExpected = if (exp.isEmpty()) null else computed == exp,
                )
            } finally {
                hashBusy.value = false
            }
        }
    }

    private suspend fun <T> withIo(block: () -> T): T =
        kotlinx.coroutines.withContext(Dispatchers.IO) { block() }
}
