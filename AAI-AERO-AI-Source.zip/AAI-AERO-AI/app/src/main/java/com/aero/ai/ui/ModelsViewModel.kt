package com.aero.ai.ui

import android.app.Application
import android.app.DownloadManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.StatFs
import android.provider.OpenableColumns
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aero.ai.R
import com.aero.ai.ai.EngineState
import com.aero.ai.ai.LlmEngine
import com.aero.ai.data.AeroDatabase
import com.aero.ai.data.CatalogModel
import com.aero.ai.data.ModelCatalog
import com.aero.ai.data.ModelEntity
import com.aero.ai.data.ModelStore
import com.aero.ai.data.PendingDownload
import com.aero.ai.data.SettingsRepository
import java.io.DataInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class HashResult(val computed: String, val matchesStored: Boolean, val matchesExpected: Boolean?)

sealed interface DlState {
    data object None : DlState
    data class Starting(val catalogId: String) : DlState
    data class Running(val catalogId: String, val done: Long, val total: Long, val waiting: Boolean) : DlState
    data class Finalizing(val catalogId: String, val percent: Int) : DlState
}

class ModelsViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AeroDatabase.get(app).modelDao()
    private val prefs = SettingsRepository(app)
    private var pollJob: Job? = null

    val models: StateFlow<List<ModelEntity>> =
        dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val activeModelId: StateFlow<String?> =
        prefs.activeModelId.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val engineState: StateFlow<EngineState> = LlmEngine.state

    /** null = no import running; -1 = size unknown. */
    val importProgress = MutableStateFlow<Int?>(null)
    val download = MutableStateFlow<DlState>(DlState.None)
    val message = MutableStateFlow<Int?>(null)
    val hashResult = MutableStateFlow<HashResult?>(null)
    val hashBusy = MutableStateFlow(false)

    init {
        // Resume tracking a download that was started before the app was closed.
        viewModelScope.launch {
            PendingDownload.decode(prefs.pendingDownload.first())?.let { startPolling(it) }
        }
    }

    fun dismissMessage() { message.value = null }
    fun clearHash() { hashResult.value = null }

    // ------------------------------------------------------------------ import from file

    fun importModel(uri: Uri) {
        if (importProgress.value != null) return
        viewModelScope.launch(Dispatchers.IO) {
            importProgress.value = -1
            message.value = null
            val ctx = getApplication<Application>()
            val id = UUID.randomUUID().toString()
            val dir = ModelStore.dir(ctx)
            val part = File(dir, "$id.part")
            try {
                var displayName = "model.gguf"
                var size = -1L
                ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val si = c.getColumnIndex(OpenableColumns.SIZE)
                        if (ni >= 0) c.getString(ni)?.let { displayName = it }
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                    }
                }
                val isGguf = runCatching {
                    ctx.contentResolver.openInputStream(uri)!!.use { ins ->
                        val magic = ByteArray(4)
                        DataInputStream(ins).readFully(magic)
                        ModelStore.isGgufMagic(magic)
                    }
                }.getOrDefault(false)
                if (!isGguf) {
                    message.value = R.string.err_not_gguf
                    return@launch
                }
                if (size > 0 && StatFs(dir.path).availableBytes < size + (64L shl 20)) {
                    message.value = R.string.err_no_space
                    return@launch
                }
                val md = MessageDigest.getInstance("SHA-256")
                var copied = 0L
                var lastPercent = -2
                ctx.contentResolver.openInputStream(uri)!!.use { ins ->
                    part.outputStream().use { out ->
                        val buf = ByteArray(1 shl 20)
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            md.update(buf, 0, n)
                            copied += n
                            val pct = if (size > 0) (copied * 100 / size).toInt().coerceIn(0, 100) else -1
                            if (pct != lastPercent) {
                                lastPercent = pct
                                importProgress.value = pct
                            }
                        }
                    }
                }
                val finalFile = File(dir, "$id.gguf")
                if (!part.renameTo(finalFile)) error("rename failed")
                dao.insert(
                    ModelEntity(
                        id = id,
                        name = displayName.removeSuffix(".gguf").removeSuffix(".GGUF"),
                        fileName = finalFile.name,
                        sizeBytes = copied,
                        sha256 = ModelStore.hex(md.digest()),
                        format = "GGUF",
                        importedAt = System.currentTimeMillis(),
                    )
                )
            } catch (e: Exception) {
                Log.e("ModelsViewModel", "import failed", e)
                part.delete()
                message.value = R.string.err_import_failed
            } finally {
                importProgress.value = null
            }
        }
    }

    // ------------------------------------------------------------------ catalog download

    private val connectivity get() = getApplication<Application>().getSystemService(ConnectivityManager::class.java)

    fun isMetered(): Boolean = connectivity.isActiveNetworkMetered

    private fun hasNetwork(): Boolean {
        val cm = connectivity
        val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun downloadDir(): File {
        val ctx = getApplication<Application>()
        return (ctx.getExternalFilesDir("models") ?: ModelStore.dir(ctx)).apply { mkdirs() }
    }

    private fun partFile(item: CatalogModel) = File(downloadDir(), "dl_${item.id}.part")

    /** Hugging Face puts the file's SHA-256 into the X-Linked-ETag header of the first (redirect) response. */
    private fun fetchExpectedSha(url: String): String? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.instanceFollowRedirects = false
        c.requestMethod = "HEAD"
        c.connectTimeout = 10_000
        c.readTimeout = 10_000
        val etag = c.getHeaderField("X-Linked-ETag")
        c.disconnect()
        ModelStore.parseLinkedEtag(etag)
    } catch (e: Exception) {
        Log.w("ModelsViewModel", "could not read expected checksum", e)
        null
    }

    fun startDownload(item: CatalogModel) {
        if (download.value != DlState.None) return
        viewModelScope.launch(Dispatchers.IO) {
            message.value = null
            if (!hasNetwork()) {
                message.value = R.string.err_no_network
                return@launch
            }
            val dir = downloadDir()
            if (StatFs(dir.path).availableBytes < item.approxBytes * 2 + (128L shl 20)) {
                message.value = R.string.err_no_space
                return@launch
            }
            download.value = DlState.Starting(item.id)
            try {
                val expected = fetchExpectedSha(item.url) ?: ""
                partFile(item).delete()
                val dm = getApplication<Application>().getSystemService(DownloadManager::class.java)
                val request = DownloadManager.Request(Uri.parse(item.url))
                    .setTitle("AERO: ${item.title}")
                    .setDescription(item.baseModel)
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalFilesDir(getApplication(), "models", partFile(item).name)
                val pending = PendingDownload(item.id, dm.enqueue(request), expected)
                prefs.setPendingDownload(pending.encode())
                startPolling(pending)
            } catch (e: Exception) {
                Log.e("ModelsViewModel", "enqueue failed", e)
                message.value = R.string.err_download_failed
                download.value = DlState.None
            }
        }
    }

    fun cancelDownload() {
        viewModelScope.launch(Dispatchers.IO) {
            pollJob?.cancel()
            PendingDownload.decode(prefs.pendingDownload.first())?.let { p ->
                getApplication<Application>().getSystemService(DownloadManager::class.java).remove(p.downloadId)
                ModelCatalog.byId(p.catalogId)?.let { partFile(it).delete() }
            }
            prefs.setPendingDownload(null)
            download.value = DlState.None
        }
    }

    private fun startPolling(p: PendingDownload) {
        pollJob?.cancel()
        pollJob = viewModelScope.launch(Dispatchers.IO) {
            val dm = getApplication<Application>().getSystemService(DownloadManager::class.java)
            val item = ModelCatalog.byId(p.catalogId)
            if (item == null) {
                prefs.setPendingDownload(null)
                return@launch
            }
            while (true) {
                var status = -1
                var done = 0L
                var total = -1L
                dm.query(DownloadManager.Query().setFilterById(p.downloadId))?.use { c ->
                    if (c.moveToFirst()) {
                        status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                        done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                        total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                    }
                }
                when (status) {
                    -1 -> { // removed by the user from the system download list
                        prefs.setPendingDownload(null)
                        download.value = DlState.None
                        return@launch
                    }
                    DownloadManager.STATUS_SUCCESSFUL -> {
                        finalizeDownload(item, p)
                        return@launch
                    }
                    DownloadManager.STATUS_FAILED -> {
                        message.value = R.string.err_download_failed
                        partFile(item).delete()
                        prefs.setPendingDownload(null)
                        download.value = DlState.None
                        return@launch
                    }
                    else -> download.value = DlState.Running(
                        catalogId = item.id,
                        done = done,
                        total = if (total > 0) total else item.approxBytes,
                        waiting = status == DownloadManager.STATUS_PAUSED || status == DownloadManager.STATUS_PENDING,
                    )
                }
                delay(1000)
            }
        }
    }

    /** Copies the finished download into private storage, verifying SHA-256 in the same pass. */
    private suspend fun finalizeDownload(item: CatalogModel, p: PendingDownload) {
        val ctx = getApplication<Application>()
        val src = partFile(item)
        var dest: File? = null
        try {
            if (!src.exists()) error("downloaded file missing")
            val id = UUID.randomUUID().toString()
            val out = File(ModelStore.dir(ctx), "$id.gguf")
            dest = out
            val md = MessageDigest.getInstance("SHA-256")
            val total = src.length()
            var copied = 0L
            var last = -1
            download.value = DlState.Finalizing(item.id, 0)
            src.inputStream().use { ins ->
                out.outputStream().use { os ->
                    val buf = ByteArray(1 shl 20)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        os.write(buf, 0, n)
                        md.update(buf, 0, n)
                        copied += n
                        val pct = if (total > 0) (copied * 100 / total).toInt() else 0
                        if (pct != last) {
                            last = pct
                            download.value = DlState.Finalizing(item.id, pct)
                        }
                    }
                }
            }
            val sha = ModelStore.hex(md.digest())
            if (p.expectedSha.isNotEmpty() && sha != p.expectedSha) {
                out.delete()
                message.value = R.string.err_download_hash
                return
            }
            val magicOk = out.inputStream().use { ins ->
                val magic = ByteArray(4)
                DataInputStream(ins).readFully(magic)
                ModelStore.isGgufMagic(magic)
            }
            if (!magicOk) {
                out.delete()
                message.value = R.string.err_not_gguf
                return
            }
            val entity = ModelEntity(
                id = id,
                name = item.displayName,
                fileName = out.name,
                sizeBytes = out.length(),
                sha256 = sha,
                format = "GGUF",
                importedAt = System.currentTimeMillis(),
            )
            dao.insert(entity)
            dest = null // keep the file
            prefs.setActiveModelId(id)
            LlmEngine.load(ctx, entity)
        } catch (e: Exception) {
            Log.e("ModelsViewModel", "finalize failed", e)
            dest?.delete()
            message.value = R.string.err_download_failed
        } finally {
            src.delete()
            prefs.setPendingDownload(null)
            download.value = DlState.None
        }
    }

    // ------------------------------------------------------------------ model actions

    fun useAsMain(model: ModelEntity) {
        viewModelScope.launch {
            prefs.setActiveModelId(model.id)
            LlmEngine.load(getApplication(), model)
        }
    }

    fun unload() {
        viewModelScope.launch { LlmEngine.unload() }
    }

    fun delete(model: ModelEntity) {
        viewModelScope.launch {
            val st = LlmEngine.state.value
            if (st is EngineState.Ready && st.modelId == model.id) LlmEngine.unload()
            if (activeModelId.value == model.id) prefs.setActiveModelId(null)
            withContext(Dispatchers.IO) { File(ModelStore.dir(getApplication()), model.fileName).delete() }
            dao.delete(model.id)
        }
    }

    fun verify(model: ModelEntity, expected: String) {
        if (hashBusy.value) return
        viewModelScope.launch {
            hashBusy.value = true
            hashResult.value = null
            try {
                val file = File(ModelStore.dir(getApplication()), model.fileName)
                val computed = withContext(Dispatchers.IO) { if (file.exists()) ModelStore.sha256(file) else "" }
                val exp = expected.trim().lowercase()
                hashResult.value = HashResult(
                    computed = computed,
                    matchesStored = computed.isNotEmpty() && computed == model.sha256,
                    matchesExpected = if (exp.isEmpty()) null else computed == exp,
                )
            } finally {
                hashBusy.value = false
            }
        }
    }
}
