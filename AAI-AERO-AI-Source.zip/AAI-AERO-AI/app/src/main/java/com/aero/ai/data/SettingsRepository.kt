package com.aero.ai.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsStore: DataStore<Preferences> by preferencesDataStore(name = "aero_settings")

class SettingsRepository(context: Context) {
    private val store = context.applicationContext.settingsStore

    val settings: Flow<AppSettings> = store.data.map { p ->
        AppSettings(
            themeMode = ThemeMode.fromName(p[THEME]),
            accent = Accent.fromName(p[ACCENT]),
            animations = p[ANIMATIONS] ?: true,
            onboardingDone = p[ONBOARDING] ?: false,
            contextSize = p[CONTEXT] ?: GenerationOptions.DEFAULT_CONTEXT,
            threads = p[THREADS] ?: GenerationOptions.DEFAULT_THREADS,
            temperature = p[TEMPERATURE] ?: GenerationOptions.DEFAULT_TEMPERATURE,
            maxTokens = p[MAX_TOKENS] ?: GenerationOptions.DEFAULT_MAX_TOKENS,
        )
    }

    val lastChatId: Flow<String?> = store.data.map { it[LAST_CHAT] }

    suspend fun setLastChatId(id: String?) {
        store.edit { if (id == null) it.remove(LAST_CHAT) else it[LAST_CHAT] = id }
    }

    val activeModelId: Flow<String?> = store.data.map { it[ACTIVE_MODEL] }

    suspend fun setActiveModelId(id: String?) {
        store.edit { if (id == null) it.remove(ACTIVE_MODEL) else it[ACTIVE_MODEL] = id }
    }

    val pendingDownload: Flow<String?> = store.data.map { it[PENDING_DOWNLOAD] }

    suspend fun setPendingDownload(value: String?) {
        store.edit { if (value == null) it.remove(PENDING_DOWNLOAD) else it[PENDING_DOWNLOAD] = value }
    }

    suspend fun setContextSize(v: Int) { store.edit { it[CONTEXT] = v } }
    suspend fun setThreads(v: Int) { store.edit { it[THREADS] = v } }
    suspend fun setTemperature(v: Float) { store.edit { it[TEMPERATURE] = v } }
    suspend fun setMaxTokens(v: Int) { store.edit { it[MAX_TOKENS] = v } }

    suspend fun setThemeMode(mode: ThemeMode) { store.edit { it[THEME] = mode.name } }
    suspend fun setAccent(accent: Accent) { store.edit { it[ACCENT] = accent.name } }
    suspend fun setAnimations(enabled: Boolean) { store.edit { it[ANIMATIONS] = enabled } }
    suspend fun setOnboardingDone() { store.edit { it[ONBOARDING] = true } }

    private companion object {
        val THEME = stringPreferencesKey("theme_mode")
        val ACCENT = stringPreferencesKey("accent")
        val ANIMATIONS = booleanPreferencesKey("animations")
        val ONBOARDING = booleanPreferencesKey("onboarding_done")
        val PENDING_DOWNLOAD = stringPreferencesKey("pending_download")
        val ACTIVE_MODEL = stringPreferencesKey("active_model_id")
        val CONTEXT = intPreferencesKey("gen_context")
        val THREADS = intPreferencesKey("gen_threads")
        val TEMPERATURE = floatPreferencesKey("gen_temperature")
        val MAX_TOKENS = intPreferencesKey("gen_max_tokens")
        val LAST_CHAT = stringPreferencesKey("last_chat_id")
    }
}
