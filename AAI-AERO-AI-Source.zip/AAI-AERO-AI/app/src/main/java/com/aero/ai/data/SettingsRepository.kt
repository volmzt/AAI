package com.aero.ai.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsStore: DataStore<Preferences> by preferencesDataStore(name = "aero_settings")

class SettingsRepository(context: Context) {
    private val store = context.applicationContext.settingsStore

    val settings: Flow<AppSettings> = store.data.map { p ->
        AppSettings(
            themeMode = ThemeMode.fromName(p[THEME]),
            accent = Accent.fromName(p[ACCENT]),
            animations = p[ANIMATIONS] ?: true,
            onboardingDone = p[ONBOARDING] ?: false,
        )
    }

    val lastChatId: Flow<String?> = store.data.map { it[LAST_CHAT] }

    suspend fun setLastChatId(id: String?) {
        store.edit { if (id == null) it.remove(LAST_CHAT) else it[LAST_CHAT] = id }
    }

    suspend fun setThemeMode(mode: ThemeMode) { store.edit { it[THEME] = mode.name } }
    suspend fun setAccent(accent: Accent) { store.edit { it[ACCENT] = accent.name } }
    suspend fun setAnimations(enabled: Boolean) { store.edit { it[ANIMATIONS] = enabled } }
    suspend fun setOnboardingDone() { store.edit { it[ONBOARDING] = true } }

    private companion object {
        val THEME = stringPreferencesKey("theme_mode")
        val ACCENT = stringPreferencesKey("accent")
        val ANIMATIONS = booleanPreferencesKey("animations")
        val ONBOARDING = booleanPreferencesKey("onboarding_done")
        val LAST_CHAT = stringPreferencesKey("last_chat_id")
    }
}
