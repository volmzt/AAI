package com.aero.ai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.aero.ai.data.Accent
import com.aero.ai.data.ThemeMode

@Composable
fun AeroTheme(mode: ThemeMode, accent: Accent, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val primary = Color(accent.argb)
    val scheme = if (dark) {
        darkColorScheme(
            primary = primary,
            onPrimary = Color.Black,
            background = Color(0xFF101010),
            onBackground = Color.White,
            surface = Color(0xFF191919),
            onSurface = Color.White,
            surfaceVariant = Color(0xFF222222),
            onSurfaceVariant = Color(0xFFA5A5A5),
            outline = Color(0xFF303030),
            error = Color(0xFFE45B5B),
        )
    } else {
        lightColorScheme(
            primary = primary,
            onPrimary = Color.Black,
            background = Color(0xFFFAFAFA),
            onBackground = Color(0xFF101010),
            surface = Color.White,
            onSurface = Color(0xFF101010),
            surfaceVariant = Color(0xFFEFEFEF),
            onSurfaceVariant = Color(0xFF5F5F5F),
            outline = Color(0xFFD5D5D5),
            error = Color(0xFFC03C3C),
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
