package com.aero.ai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.material3.Typography
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.aero.ai.data.Accent
import com.aero.ai.data.ThemeMode

private val AeroTypography = Typography(
    displayMedium = TextStyle(fontSize = 44.sp, lineHeight = 48.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp),
    headlineLarge = TextStyle(fontSize = 32.sp, lineHeight = 38.sp, fontWeight = FontWeight.Bold),
    headlineMedium = TextStyle(fontSize = 26.sp, lineHeight = 32.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 21.sp, lineHeight = 27.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 17.sp, lineHeight = 23.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontSize = 13.sp, lineHeight = 18.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp),
    labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 14.sp, fontWeight = FontWeight.Medium),
)

@Composable
fun AeroTheme(mode: ThemeMode, accent: Accent, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val primary = Color(accent.argb)
    val scheme = if (dark) {
        darkColorScheme(
            primary = primary,
            onPrimary = Color.Black,
            background = Color(0xFF101010),
            onBackground = Color.White,
            surface = Color(0xFF191919),
            onSurface = Color.White,
            surfaceVariant = Color(0xFF222222),
            onSurfaceVariant = Color(0xFFA5A5A5),
            outline = Color(0xFF303030),
            error = Color(0xFFE45B5B),
        )
    } else {
        lightColorScheme(
            primary = primary,
            onPrimary = Color.Black,
            background = Color(0xFFFAFAFA),
            onBackground = Color(0xFF101010),
            surface = Color.White,
            onSurface = Color(0xFF101010),
            surfaceVariant = Color(0xFFEFEFEF),
            onSurfaceVariant = Color(0xFF5F5F5F),
            outline = Color(0xFFD5D5D5),
            error = Color(0xFFC03C3C),
        )
    }
    MaterialTheme(colorScheme = scheme, typography = AeroTypography, content = content)
}
