package com.aero.ai.ai

import java.nio.ByteBuffer
import java.nio.CharBuffer
import java.nio.charset.CodingErrorAction

/**
 * Turns a stream of byte chunks into text. A token can end in the middle of a multi-byte character
 * (emoji, Cyrillic), so incomplete trailing bytes are held back until the next chunk arrives.
 */
class Utf8Stream {
    private val decoder = Charsets.UTF_8.newDecoder()
        .onMalformedInput(CodingErrorAction.REPLACE)
        .onUnmappableCharacter(CodingErrorAction.REPLACE)
    private var carry = ByteArray(0)

    fun push(bytes: ByteArray): String {
        val all = carry + bytes
        val input = ByteBuffer.wrap(all)
        val out = CharBuffer.allocate(all.size + 4)
        decoder.decode(input, out, false)
        carry = ByteArray(input.remaining())
        input.get(carry)
        out.flip()
        return out.toString()
    }

    fun finish(): String {
        val input = ByteBuffer.wrap(carry)
        val out = CharBuffer.allocate(carry.size + 4)
        decoder.decode(input, out, true)
        decoder.flush(out)
        carry = ByteArray(0)
        out.flip()
        return out.toString()
    }
}
