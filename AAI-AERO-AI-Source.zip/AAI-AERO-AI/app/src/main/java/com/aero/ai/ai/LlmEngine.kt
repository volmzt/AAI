package com.aero.ai.ai

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.util.Log
import androidx.annotation.StringRes
import com.aero.ai.R
import com.aero.ai.data.ModelEntity
import com.aero.ai.data.ModelStore
import java.io.File
import java.util.concurrent.Executors
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

data class ChatTurn(val role: String, val text: String)

sealed interface EngineState {
    data object Idle : EngineState
    data object Loading : EngineState
    data class Ready(val modelId: String, val name: String, val info: String) : EngineState
    data class Failed(@StringRes val messageRes: Int) : EngineState
}

sealed interface GenResult {
    data object Done : GenResult
    data class Failed(@StringRes val messageRes: Int) : GenResult
}

/** Process-wide holder of the loaded model. All native calls run on one dedicated thread, never on the UI thread. */
object LlmEngine {
    private const val TAG = "LlmEngine"
    private val dispatcher = Executors.newSingleThreadExecutor { r -> Thread(r, "aero-llm") }.asCoroutineDispatcher()

    private val _state = MutableStateFlow<EngineState>(EngineState.Idle)
    val state: StateFlow<EngineState> = _state.asStateFlow()

    private var handle = 0L
    private var loadedId: String? = null

    suspend fun load(context: Context, model: ModelEntity): Boolean = withContext(dispatcher) {
        if (handle != 0L && loadedId == model.id) return@withContext true
        if (!NativeBridge.isAvailable || !Build.SUPPORTED_ABIS.contains("arm64-v8a")) {
            _state.value = EngineState.Failed(R.string.err_native_unavailable)
            return@withContext false
        }
        _state.value = EngineState.Loading
        unloadInternal()
        val file = File(ModelStore.dir(context), model.fileName)
        if (!file.exists()) {
            _state.value = EngineState.Failed(R.string.err_model_missing)
            return@withContext false
        }
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        if (file.length() > mi.totalMem * 0.6) {
            _state.value = EngineState.Failed(R.string.err_not_enough_memory)
            return@withContext false
        }
        val h = NativeBridge.nativeLoad(file.absolutePath)
        if (h == 0L) {
            Log.e(TAG, "load failed: ${NativeBridge.nativeLastError()}")
            _state.value = EngineState.Failed(R.string.err_model_unsupported)
            return@withContext false
        }
        handle = h
        loadedId = model.id
        _state.value = EngineState.Ready(model.id, model.name, NativeBridge.nativeInfo(h))
        true
    }

    suspend fun unload() = withContext(dispatcher) {
        unloadInternal()
        _state.value = EngineState.Idle
    }

    private fun unloadInternal() {
        if (handle != 0L) NativeBridge.nativeFree(handle)
        handle = 0L
        loadedId = null
    }

    /** Asks the running generation to stop; safe to call from any thread. */
    fun cancel() {
        if (NativeBridge.isAvailable) NativeBridge.nativeCancel()
    }

    suspend fun generate(
        turns: List<ChatTurn>,
        contextSize: Int,
        threads: Int,
        maxTokens: Int,
        temperature: Float,
        onText: (String) -> Unit,
    ): GenResult = withContext(dispatcher) {
        generateBlocking(turns, contextSize, threads, maxTokens, temperature, onText)
    }

    private fun generateBlocking(
        turns: List<ChatTurn>,
        contextSize: Int,
        threads: Int,
        maxTokens: Int,
        temperature: Float,
        onText: (String) -> Unit,
    ): GenResult {
        if (handle == 0L) return GenResult.Failed(R.string.err_model_unsupported)
        var current = turns
        while (true) {
            val stream = Utf8Stream()
            val callback = TokenCallback { bytes ->
                val s = stream.push(bytes)
                if (s.isNotEmpty()) onText(s)
                true
            }
            val error = NativeBridge.nativeGenerate(
                handle,
                current.map { it.role }.toTypedArray(),
                current.map { it.text.toByteArray(Charsets.UTF_8) }.toTypedArray(),
                contextSize, threads, maxTokens, temperature, 0.9f, callback,
            )
            when (error) {
                null -> {
                    val tail = stream.finish()
                    if (tail.isNotEmpty()) onText(tail)
                    return GenResult.Done
                }
                "context_full" -> {
                    // Drop the oldest non-system message and try again (the stored history is untouched).
                    val droppable = current.count { it.role != "system" }
                    val idx = current.indexOfFirst { it.role != "system" }
                    if (droppable <= 1 || idx < 0) return GenResult.Failed(R.string.err_context)
                    current = current.toMutableList().also { it.removeAt(idx) }
                }
                else -> {
                    Log.e(TAG, "generation failed: $error")
                    return GenResult.Failed(R.string.err_generation)
                }
            }
        }
    }
}
