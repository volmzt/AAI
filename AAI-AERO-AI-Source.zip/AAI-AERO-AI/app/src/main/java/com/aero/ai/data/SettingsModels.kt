package com.aero.ai.data

enum class ThemeMode {
    SYSTEM, DARK, LIGHT;

    companion object {
        fun fromName(name: String?): ThemeMode = entries.firstOrNull { it.name == name } ?: SYSTEM
    }
}

enum class AppLanguage(val tag: String) {
    SYSTEM(""), RU("ru"), UK("uk"), EN("en");

    companion object {
        fun fromTags(tags: String): AppLanguage =
            entries.firstOrNull { it.tag.isNotEmpty() && tags.startsWith(it.tag) } ?: SYSTEM
    }
}

enum class Accent(val argb: Long) {
    ORANGE(0xFFFF8A24),
    BLUE(0xFF4C9AFF),
    GREEN(0xFF45B97C),
    PURPLE(0xFFA78BFA);

    companion object {
        fun fromName(name: String?): Accent = entries.firstOrNull { it.name == name } ?: ORANGE
    }
}

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accent: Accent = Accent.ORANGE,
    val animations: Boolean = true,
    val onboardingDone: Boolean = false,
)
