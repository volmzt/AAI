package com.aero.ai.data

enum class ThemeMode {
    SYSTEM, DARK, LIGHT;

    companion object {
        fun fromName(name: String?): ThemeMode = entries.firstOrNull { it.name == name } ?: SYSTEM
    }
}

enum class AppLanguage(val tag: String) {
    SYSTEM(""), RU("ru"), UK("uk"), EN("en");

    companion object {
        fun fromTags(tags: String): AppLanguage =
            entries.firstOrNull { it.tag.isNotEmpty() && tags.startsWith(it.tag) } ?: SYSTEM
    }
}

enum class Accent(val argb: Long) {
    ORANGE(0xFFFF8A24),
    BLUE(0xFF4C9AFF),
    GREEN(0xFF45B97C),
    PURPLE(0xFFA78BFA);

    companion object {
        fun fromName(name: String?): Accent = entries.firstOrNull { it.name == name } ?: ORANGE
    }
}

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accent: Accent = Accent.ORANGE,
    val animations: Boolean = true,
    val onboardingDone: Boolean = false,
    val contextSize: Int = GenerationOptions.DEFAULT_CONTEXT,
    val threads: Int = GenerationOptions.DEFAULT_THREADS,
    val temperature: Float = GenerationOptions.DEFAULT_TEMPERATURE,
    val maxTokens: Int = GenerationOptions.DEFAULT_MAX_TOKENS,
)

object GenerationOptions {
    const val DEFAULT_CONTEXT = 4096
    const val DEFAULT_THREADS = 4
    const val DEFAULT_TEMPERATURE = 0.7f
    const val DEFAULT_MAX_TOKENS = 1024
    val contexts = listOf(2048, 4096, 8192)
    val threads = listOf(2, 4, 6, 8)
    val temperatures = listOf(0.2f, 0.7f, 1.0f)
    val maxTokens = listOf(256, 512, 1024, 2048)
}
