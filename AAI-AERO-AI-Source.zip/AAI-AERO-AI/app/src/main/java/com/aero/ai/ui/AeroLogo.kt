package com.aero.ai.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun AeroLogo(
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    color: Color = MaterialTheme.colorScheme.primary,
) {
    Canvas(modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val stroke = w * 0.14f
        val a = Path().apply {
            moveTo(w * 0.12f, h * 0.9f)
            lineTo(w * 0.5f, h * 0.1f)
            lineTo(w * 0.88f, h * 0.9f)
        }
        drawPath(a, color, style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawLine(
            color,
            Offset(w * 0.3f, h * 0.62f),
            Offset(w * 0.7f, h * 0.62f),
            strokeWidth = stroke,
            cap = StrokeCap.Round,
        )
    }
}
