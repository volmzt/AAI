// JNI bridge between Kotlin (com.aero.ai.ai.NativeBridge) and llama.cpp.
// Design: every generation builds a fresh context from the full chat history (no KV-cache reuse).
// This is slower on very long chats but keeps the code simple and robust.
#include <jni.h>
#include <android/log.h>

#include <algorithm>
#include <atomic>
#include <string>
#include <vector>

#include "llama.h"

namespace {

constexpr const char* TAG = "AeroNative";
std::atomic<bool> g_cancel{false};
bool g_backend_ready = false;
std::string g_last_error;

void log_cb(ggml_log_level level, const char* text, void*) {
    if (level == GGML_LOG_LEVEL_DEBUG) return;
    int prio = ANDROID_LOG_INFO;
    if (level == GGML_LOG_LEVEL_ERROR) prio = ANDROID_LOG_ERROR;
    else if (level == GGML_LOG_LEVEL_WARN) prio = ANDROID_LOG_WARN;
    __android_log_write(prio, TAG, text);
}

std::string jstr(JNIEnv* env, jstring s) {
    if (!s) return "";
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string r = c ? c : "";
    if (c) env->ReleaseStringUTFChars(s, c);
    return r;
}

jstring fail(JNIEnv* env, const char* msg) {
    g_last_error = msg;
    __android_log_print(ANDROID_LOG_ERROR, TAG, "%s", msg);
    return env->NewStringUTF(msg);
}

struct Guard {
    llama_context* ctx = nullptr;
    llama_sampler* smpl = nullptr;
    ~Guard() {
        if (smpl) llama_sampler_free(smpl);
        if (ctx) llama_free(ctx);
    }
};

}  // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_aero_ai_ai_NativeBridge_nativeLoad(JNIEnv* env, jobject, jstring path) {
    if (!g_backend_ready) {
        llama_log_set(log_cb, nullptr);
        llama_backend_init();
        g_backend_ready = true;
    }
    std::string p = jstr(env, path);
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    mp.use_mmap = true;
    llama_model* model = llama_model_load_from_file(p.c_str(), mp);
    if (!model) {
        g_last_error = "model load failed";
        return 0;
    }
    return reinterpret_cast<jlong>(model);
}

JNIEXPORT void JNICALL
Java_com_aero_ai_ai_NativeBridge_nativeFree(JNIEnv*, jobject, jlong handle) {
    if (handle != 0) llama_model_free(reinterpret_cast<llama_model*>(handle));
}

JNIEXPORT jstring JNICALL
Java_com_aero_ai_ai_NativeBridge_nativeInfo(JNIEnv* env, jobject, jlong handle) {
    auto* model = reinterpret_cast<llama_model*>(handle);
    if (!model) return env->NewStringUTF("");
    char desc[256] = {0};
    llama_model_desc(model, desc, sizeof(desc));
    std::string s = std::string(desc) + "|" + std::to_string(llama_model_size(model)) + "|" +
                    std::to_string(llama_model_n_ctx_train(model)) + "|" +
                    std::to_string(llama_model_n_params(model));
    return env->NewStringUTF(s.c_str());
}

JNIEXPORT jstring JNICALL
Java_com_aero_ai_ai_NativeBridge_nativeLastError(JNIEnv* env, jobject) {
    return env->NewStringUTF(g_last_error.c_str());
}

JNIEXPORT void JNICALL
Java_com_aero_ai_ai_NativeBridge_nativeCancel(JNIEnv*, jobject) {
    g_cancel.store(true);
}

// Returns null on success (also when cancelled), otherwise a short error code:
// "context_full", "template", "tokenize", "context", "decode", "model".
JNIEXPORT jstring JNICALL
Java_com_aero_ai_ai_NativeBridge_nativeGenerate(
        JNIEnv* env, jobject, jlong handle, jobjectArray roles, jobjectArray contents,
        jint n_ctx, jint n_threads, jint max_tokens, jfloat temperature, jfloat top_p,
        jobject callback) {
    g_cancel.store(false);
    auto* model = reinterpret_cast<llama_model*>(handle);
    if (!model) return fail(env, "model");

    // --- chat messages
    const jsize n_msg = env->GetArrayLength(roles);
    std::vector<std::string> role_s(n_msg), content_s(n_msg);
    size_t total_chars = 0;
    for (jsize i = 0; i < n_msg; ++i) {
        auto jr = (jstring) env->GetObjectArrayElement(roles, i);
        role_s[i] = jstr(env, jr);
        env->DeleteLocalRef(jr);
        auto jc = (jbyteArray) env->GetObjectArrayElement(contents, i);
        const jsize len = env->GetArrayLength(jc);
        content_s[i].resize(len);
        if (len > 0) env->GetByteArrayRegion(jc, 0, len, reinterpret_cast<jbyte*>(&content_s[i][0]));
        env->DeleteLocalRef(jc);
        total_chars += content_s[i].size();
    }
    std::vector<llama_chat_message> msgs;
    msgs.reserve(n_msg);
    for (jsize i = 0; i < n_msg; ++i) msgs.push_back({role_s[i].c_str(), content_s[i].c_str()});

    // --- prompt via the model's own chat template (fallback: chatml)
    std::string prompt;
    auto apply = [&](const char* tmpl) -> bool {
        std::vector<char> buf(4096 + total_chars * 2);
        int32_t n = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(), (int32_t) buf.size());
        if (n < 0) return false;
        if ((size_t) n > buf.size()) {
            buf.resize(n);
            n = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(), (int32_t) buf.size());
            if (n < 0) return false;
        }
        prompt.assign(buf.data(), (size_t) n);
        return true;
    };
    const char* model_tmpl = llama_model_chat_template(model, nullptr);
    if (!((model_tmpl && apply(model_tmpl)) || apply("chatml"))) return fail(env, "template");

    // --- tokenize
    const llama_vocab* vocab = llama_model_get_vocab(model);
    int n_tok = -llama_tokenize(vocab, prompt.c_str(), (int32_t) prompt.size(), nullptr, 0, true, true);
    if (n_tok <= 0) return fail(env, "tokenize");
    std::vector<llama_token> tokens(n_tok);
    if (llama_tokenize(vocab, prompt.c_str(), (int32_t) prompt.size(), tokens.data(), n_tok, true, true) < 0)
        return fail(env, "tokenize");
    if (n_tok + 16 > n_ctx) return fail(env, "context_full");
    int budget = std::min<int>(max_tokens, n_ctx - n_tok - 1);

    // --- context + sampler
    Guard g;
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = (uint32_t) n_ctx;
    cp.n_batch = 512;
    cp.n_threads = n_threads;
    cp.n_threads_batch = n_threads;
    g.ctx = llama_init_from_model(model, cp);
    if (!g.ctx) return fail(env, "context");

    g.smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (temperature <= 0.0f) {
        llama_sampler_chain_add(g.smpl, llama_sampler_init_greedy());
    } else {
        llama_sampler_chain_add(g.smpl, llama_sampler_init_top_k(40));
        llama_sampler_chain_add(g.smpl, llama_sampler_init_top_p(top_p, 1));
        llama_sampler_chain_add(g.smpl, llama_sampler_init_temp(temperature));
        llama_sampler_chain_add(g.smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    }

    // --- prompt prefill in chunks
    for (int i = 0; i < n_tok; i += 512) {
        if (g_cancel.load()) return nullptr;
        const int n = std::min(512, n_tok - i);
        llama_batch b = llama_batch_get_one(tokens.data() + i, n);
        if (llama_decode(g.ctx, b) != 0) return fail(env, "decode");
    }

    // --- callback plumbing
    jclass cb_cls = env->GetObjectClass(callback);
    jmethodID on_token = env->GetMethodID(cb_cls, "onToken", "([B)Z");
    if (!on_token) return fail(env, "callback");

    // --- generation loop
    int n_past = n_tok;
    for (int i = 0; i < budget && !g_cancel.load(); ++i) {
        llama_token tok = llama_sampler_sample(g.smpl, g.ctx, -1);
        if (llama_vocab_is_eog(vocab, tok)) break;

        char piece[512];
        const int pn = llama_token_to_piece(vocab, tok, piece, sizeof(piece), 0, false);
        if (pn > 0) {
            jbyteArray arr = env->NewByteArray(pn);
            env->SetByteArrayRegion(arr, 0, pn, reinterpret_cast<const jbyte*>(piece));
            const jboolean keep_going = env->CallBooleanMethod(callback, on_token, arr);
            env->DeleteLocalRef(arr);
            if (env->ExceptionCheck()) {
                env->ExceptionClear();
                break;
            }
            if (!keep_going) break;
        }

        if (n_past + 1 >= n_ctx) break;
        llama_batch b = llama_batch_get_one(&tok, 1);
        if (llama_decode(g.ctx, b) != 0) return fail(env, "decode");
        n_past++;
    }
    return nullptr;
}

}  // extern "C"
