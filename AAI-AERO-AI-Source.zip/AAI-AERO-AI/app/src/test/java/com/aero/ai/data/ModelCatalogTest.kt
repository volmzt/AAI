package com.aero.ai.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelCatalogTest {
    @Test fun catalogIdsAreUniqueAndOneIsRecommended() {
        val ids = ModelCatalog.all.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
        assertEquals(1, ModelCatalog.all.count { it.recommended })
    }

    @Test fun urlsPointToHuggingFaceGgufFiles() {
        ModelCatalog.all.forEach {
            assertTrue(it.url.startsWith("https://huggingface.co/Qwen/"))
            assertTrue(it.url.contains("/resolve/main/"))
            assertTrue(it.url.endsWith(".gguf"))
        }
    }

    @Test fun lookupById() {
        assertNotNull(ModelCatalog.byId("aero-standard"))
        assertNull(ModelCatalog.byId("nope"))
    }

    @Test fun pendingDownloadRoundTrip() {
        val p = PendingDownload("aero-lite", 42L, "ab".repeat(32))
        assertEquals(p, PendingDownload.decode(p.encode()))
        assertNull(PendingDownload.decode(null))
        assertNull(PendingDownload.decode("broken"))
        assertNull(PendingDownload.decode("a|notanumber|c"))
    }

    @Test fun linkedEtagParsing() {
        val sha = "0123456789abcdef".repeat(4)
        assertEquals(sha, ModelStore.parseLinkedEtag("\"$sha\""))
        assertNull(ModelStore.parseLinkedEtag("W/\"short\""))
        assertNull(ModelStore.parseLinkedEtag(null))
    }
}
