package com.aero.ai.data

import org.junit.Assert.assertEquals
import org.junit.Test

class ChatTextTest {
    @Test fun titleUsesFirstNonEmptyLine() {
        assertEquals("hello", ChatText.titleFrom("  \n  hello  \nworld"))
    }

    @Test fun titleIsTruncatedWithEllipsis() {
        assertEquals("a".repeat(40) + "…", ChatText.titleFrom("a".repeat(50)))
        assertEquals("a".repeat(40), ChatText.titleFrom("a".repeat(40)))
    }

    @Test fun titleOfBlankTextIsEmpty() {
        assertEquals("", ChatText.titleFrom("   \n "))
    }

    @Test fun escapeLikeEscapesWildcards() {
        assertEquals("50\\%\\_x\\\\", ChatText.escapeLike("50%_x\\"))
        assertEquals("plain", ChatText.escapeLike("plain"))
    }
}
