package com.aero.ai.data

import org.junit.Assert.assertEquals
import org.junit.Test

class SettingsModelsTest {
    @Test fun themeModeFallsBackToSystem() {
        assertEquals(ThemeMode.SYSTEM, ThemeMode.fromName(null))
        assertEquals(ThemeMode.SYSTEM, ThemeMode.fromName("nonsense"))
        assertEquals(ThemeMode.DARK, ThemeMode.fromName("DARK"))
    }

    @Test fun accentFallsBackToOrange() {
        assertEquals(Accent.ORANGE, Accent.fromName("missing"))
        assertEquals(Accent.GREEN, Accent.fromName("GREEN"))
    }

    @Test fun languageParsedFromTags() {
        assertEquals(AppLanguage.SYSTEM, AppLanguage.fromTags(""))
        assertEquals(AppLanguage.UK, AppLanguage.fromTags("uk-UA"))
        assertEquals(AppLanguage.RU, AppLanguage.fromTags("ru"))
        assertEquals(AppLanguage.SYSTEM, AppLanguage.fromTags("de"))
    }

    @Test fun defaultsRequireOnboarding() {
        assertEquals(false, AppSettings().onboardingDone)
    }
}
