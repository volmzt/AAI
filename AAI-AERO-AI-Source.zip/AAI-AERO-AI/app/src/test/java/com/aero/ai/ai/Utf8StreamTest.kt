package com.aero.ai.ai

import org.junit.Assert.assertEquals
import org.junit.Test

class Utf8StreamTest {
    @Test fun emojiSplitAcrossChunksIsHeldBack() {
        val bytes = "😀".toByteArray(Charsets.UTF_8) // 4 bytes
        val s = Utf8Stream()
        assertEquals("", s.push(bytes.copyOfRange(0, 2)))
        assertEquals("😀", s.push(bytes.copyOfRange(2, 4)))
        assertEquals("", s.finish())
    }

    @Test fun cyrillicSplitInsideCharacter() {
        val bytes = "Привіт".toByteArray(Charsets.UTF_8)
        val s = Utf8Stream()
        val sb = StringBuilder()
        for (b in bytes) sb.append(s.push(byteArrayOf(b))) // one byte at a time
        sb.append(s.finish())
        assertEquals("Привіт", sb.toString())
    }

    @Test fun truncatedTailBecomesReplacementCharacter() {
        val s = Utf8Stream()
        s.push(byteArrayOf(0xF0.toByte(), 0x9F.toByte()))
        assertEquals("\uFFFD", s.finish())
    }
}
