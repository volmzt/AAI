package com.aero.ai.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelStoreTest {
    @Test fun ggufMagicIsRecognised() {
        assertTrue(ModelStore.isGgufMagic("GGUF".toByteArray(Charsets.US_ASCII)))
        assertFalse(ModelStore.isGgufMagic("GGML".toByteArray(Charsets.US_ASCII)))
        assertFalse(ModelStore.isGgufMagic(byteArrayOf(1, 2)))
    }

    @Test fun hexEncodesBytes() {
        assertEquals("000fff", ModelStore.hex(byteArrayOf(0, 15, -1)))
    }

    @Test fun generationDefaultsAreOfferedOptions() {
        val s = AppSettings()
        assertTrue(s.contextSize in GenerationOptions.contexts)
        assertTrue(s.threads in GenerationOptions.threads)
        assertTrue(s.temperature in GenerationOptions.temperatures)
        assertTrue(s.maxTokens in GenerationOptions.maxTokens)
    }
}
