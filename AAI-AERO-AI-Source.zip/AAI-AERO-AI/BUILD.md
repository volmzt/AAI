# Сборка APK через GitHub Actions

1. Создайте пустой репозиторий на GitHub.
2. Распакуйте `AAI-AERO-AI-Source.zip` и загрузите **содержимое папки `AAI-AERO-AI`** в корень репозитория
   (файлы `settings.gradle.kts`, `app/`, `.github/` должны лежать в корне, скрытую папку `.github` не пропустите).
3. Откройте вкладку **Actions**. Workflow **Build APK** запустится при push; также можно нажать **Run workflow**.
4. После зелёной сборки откройте запуск → раздел **Artifacts**:
   - `AAI-AERO-AI-debug` — APK для установки и тестов (подписан отладочным ключом);
   - `AAI-AERO-AI-release` — release APK (без подписи, если секреты не заданы; такой APK не установится);
   - `unit-test-reports` — отчёты тестов.

## Gradle Wrapper
В архиве нет `gradle-wrapper.jar` (бинарный файл нельзя было получить без сети). CI не требует wrapper:
Gradle 8.10.2 ставится действием `gradle/actions/setup-gradle`. Для локальной работы выполните один раз
`gradle wrapper --gradle-version 8.10.2` и закоммитьте созданные файлы.

## Установка на POCO F6 Pro
1. Скачайте artifact `AAI-AERO-AI-debug`, распакуйте ZIP, получите `AAI-AERO-AI-debug.apk`.
2. Перенесите на телефон, откройте файл, разрешите установку из этого источника (MIUI/HyperOS спросит сам).
3. Установите. Приложение работает на arm64 без дополнительных библиотек.

## Подпись release (по желанию)
Создайте keystore и добавьте в **Settings → Secrets and variables → Actions**:
`AERO_KEYSTORE_BASE64` (keystore в base64, `base64 -w0 release.jks`), `AERO_KEYSTORE_PASSWORD`, `AERO_KEY_ALIAS`, `AERO_KEY_PASSWORD`.
Тогда артефакт будет называться `AAI-AERO-AI-release-signed.apk`. Keystore в репозиторий не добавляйте.

## Что не проверено
Сборка и тесты в моей среде не запускались (нет сети для загрузки Android SDK/зависимостей). Первый запуск Actions —
это первая реальная проверка. Если он упадёт, пришлите лог ошибки — исправлю.
